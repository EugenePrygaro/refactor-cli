import cx from "classnames";
import {
  type CSSProperties,
  type KeyboardEvent,
  useEffect,
  useRef,
  useState,
} from "react";
import _ from "underscore";
import { Box } from "metabase/ui";
import S from "./AccordionList.module.css";
import {
  AccordionListCell,
  type SharedAccordionProps,
} from "./AccordionListCell";
import type { Item, Row, SearchProps, Section } from "./types";
import {
  type Cursor,
  getNextCursor,
  getPrevCursor,
  searchFilter,
} from "./utils";

type Props<
  TItem extends Item,
  TSection extends Section<TItem> = Section<TItem>,
> = SharedAccordionProps<TItem, TSection> & {
  "data-testid"?: string | null;
  alwaysTogglable?: boolean;
  className?: string;
  globalSearch?: boolean;
  hasInitialFocus?: boolean;
  hideSingleSectionTitle?: boolean;
  initiallyOpenSection?: number | null;
  id?: string;
  onChange?: (item: TItem) => void;
  onChangeSection?: (section: TSection, sectionIndex: number) => boolean | void;
  onChangeSearchText?: (searchText: string) => void;
  openSection?: number;
  role?: string;
  searchProp?: SearchProps<TItem>;
  searchable?: boolean | ((section: Section) => boolean | undefined);
  sections: TSection[];
  style?: CSSProperties;

  // TODO: pass width to this component as solely number or string if possible
  // currently prop is number on initialization, then string afterwards
  width?: string | number;
  maxHeight?: number;
};

const instanceContext: { props: any } = { props: {} };

function AccordionListInternal<
  TItem extends Item,
  TSection extends Section<TItem> = Section<TItem>,
>(this: any, props: Props<TItem, TSection>) {
  instanceContext.props = props;
  if (this) {
    this.props = props;
  }

  const {
    id,
    style = {},
    width = 300,
    className,
    globalSearch = false,
    sections,
    "data-testid": testId,
    alwaysExpanded = false,
    alwaysTogglable = false,
    hideSingleSectionTitle = false,
    initiallyOpenSection,
    searchable = (section: TSection) =>
      section?.items && section.items.length > 10,
    searchProp,
    itemIsSelected,
    onChange,
    onChangeSection,
    onChangeSearchText,
    hasInitialFocus,
  } = props;

  const sectionIsSelected = (_section: Section, sectionIndex: number) => {
    let selectedSection = null;
    for (let i = 0; i < sections.length; i++) {
      if (
        _.some(sections[i]?.items ?? [], (item) =>
          Boolean(itemIsSelected?.(item, i)),
        )
      ) {
        selectedSection = i;
        break;
      }
    }
    return selectedSection === sectionIndex;
  };

  const [openSectionState, setOpenSectionState] = useState<number | null>(
    () => {
      let initial: number | undefined | null;
      if (initiallyOpenSection !== undefined) {
        initial = initiallyOpenSection;
      }
      if (initial === undefined) {
        const found = _.findIndex(sections, (section, index) =>
          sectionIsSelected(section, index),
        );
        if (found !== -1) {
          initial = found;
        }
      }
      if (initial === undefined) {
        initial = 0;
      }
      return initial;
    },
  );

  const [searchText, setSearchText] = useState("");
  const [cursor, setCursor] = useState<Cursor | null>(null);

  const listRootRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      const container = listRootRef.current;
      const hasFocusedChildren = container?.contains(document.activeElement);
      if (!hasFocusedChildren && hasInitialFocus) {
        container?.focus();
      }

      container?.querySelector("[aria-selected=true]")?.scrollIntoView({
        block: "center",
      });
    }, 0);

    return () => clearTimeout(timer);
  }, [hasInitialFocus]);

  const getOpenSection = () => {
    if (sections.length === 1) {
      return 0;
    }

    let openSec = openSectionState;
    if (openSec === undefined) {
      for (const [index, section] of sections.entries()) {
        if (sectionIsSelected(section, index)) {
          openSec = index;
          break;
        }
      }
    }
    return openSec;
  };

  const toggleSection = (sectionIndex: number) => {
    if (onChangeSection) {
      if (onChangeSection(sections[sectionIndex], sectionIndex) === false) {
        return;
      }
    }

    const openSec = getOpenSection();
    if (openSec === sectionIndex) {
      setOpenSectionState(null);
    } else {
      setOpenSectionState(sectionIndex);
    }
  };

  const handleChange = (item: TItem) => {
    onChange?.(item);
  };

  const handleChangeSearchText = (newSearchText: string) => {
    setSearchText(newSearchText);
    setCursor(null);
    onChangeSearchText?.(newSearchText);
  };

  const getFirstSelectedItemCursor = () => {
    const isSelected = itemIsSelected ?? (() => false);

    for (let sectionIndex = 0; sectionIndex < sections.length; sectionIndex++) {
      const section = sections[sectionIndex];
      for (
        let itemIndex = 0;
        itemIndex < (section.items?.length ?? 0);
        itemIndex++
      ) {
        const item = section.items?.[itemIndex];
        if (item && isSelected(item, itemIndex)) {
          return {
            sectionIndex,
            itemIndex,
          };
        }
      }
    }
    return null;
  };

  const getInitialCursor = () => {
    if (searchText.length === 0) {
      return getFirstSelectedItemCursor();
    }
    return null;
  };

  const canSelectSection = (sectionIndex: number) => {
    const section = sections[sectionIndex];
    if (!section) {
      return false;
    }

    if (section.type === "action") {
      return true;
    }

    return !alwaysExpanded && !(globalSearch && searchText.length > 0);
  };

  const getRows = (): Row<TItem, TSection>[] => {
    const openSec = getOpenSection();
    const isSearching = searchText.length > 0;

    let isGlobalSearch = globalSearch;

    const sectionIsExpanded = (sectionIndex: number) =>
      alwaysExpanded ||
      openSec === sectionIndex ||
      (isGlobalSearch && isSearching);

    const sectionIsSearchable = (sectionIndex: number) =>
      typeof searchable === "function"
        ? searchable(sections[sectionIndex])
        : searchable;

    const rowsList: Row<TItem, TSection>[] = [];

    const sortedSections = searchFilter({
      sections,
      searchText,
      searchProp,
    });

    for (const { section, sectionIndex, items } of sortedSections) {
      const isLastSection = sectionIndex === sections.length - 1;

      if (
        section.name &&
        (!hideSingleSectionTitle || sections.length > 1 || alwaysTogglable)
      ) {
        if (
          !searchable ||
          !isGlobalSearch ||
          items?.length > 0 ||
          section.type === "action"
        ) {
          if (section.type === "action") {
            rowsList.push({
              type: "action",
              section,
              sectionIndex,
              isLastSection,
            });
          } else {
            rowsList.push({
              type: "header",
              section,
              sectionIndex,
              isLastSection,
            });
          }
        }
      }
      if (
        sectionIsSearchable(sectionIndex) &&
        sectionIsExpanded(sectionIndex) &&
        section.items &&
        section.items.length > 0 &&
        !section.loading &&
        !isGlobalSearch
      ) {
        if (alwaysExpanded) {
          isGlobalSearch = true;
        } else {
          rowsList.push({
            type: "search",
            section,
            sectionIndex,
            isLastSection,
          });
        }
      }
      if (
        sectionIsExpanded(sectionIndex) &&
        section.items &&
        section.items.length > 0 &&
        !section.loading
      ) {
        for (const { itemIndex, item } of items) {
          const isLastItem = itemIndex === section.items.length - 1;
          rowsList.push({
            type: "item",
            section,
            sectionIndex,
            isLastSection,
            item,
            itemIndex,
            isLastItem,
          });
        }
      }
      if (sectionIsExpanded(sectionIndex) && section.loading) {
        rowsList.push({
          type: "loading",
          section,
          sectionIndex,
          isLastSection,
        });
      }
    }

    const syntheticSection: TSection = {} as TSection;

    if (isGlobalSearch) {
      const isEmpty =
        rowsList.filter((row) => row.type === "item").length === 0;

      if (isSearching && isEmpty) {
        rowsList.unshift({
          type: "no-results",
          section: syntheticSection,
          sectionIndex: 0,
          isLastSection: false,
        });
      }

      rowsList.unshift({
        type: "search",
        section: syntheticSection,
        sectionIndex: 0,
        isLastSection: false,
      });
    } else if (isSearching) {
      const hasItems = rowsList.some((row) => row.type === "item");
      const hasSearchRow = rowsList.some((row) => row.type === "search");
      const isListSearchable = sections.some(
        (sec, sectionIndex) =>
          sectionIsSearchable(sectionIndex) &&
          sectionIsExpanded(sectionIndex) &&
          sec.items &&
          sec.items.length > 0 &&
          !sec.loading,
      );

      if (isListSearchable && !hasItems) {
        if (!hasSearchRow) {
          rowsList.unshift({
            type: "search",
            section: syntheticSection,
            sectionIndex: 0,
            isLastSection: false,
          });
        }

        rowsList.push({
          type: "no-results",
          section: syntheticSection,
          sectionIndex: 0,
          isLastSection: false,
        });
      }
    }

    return rowsList;
  };

  const handleKeyDown = (event: KeyboardEvent) => {
    if (event.nativeEvent.isComposing) {
      return;
    }

    if (event.key === "ArrowUp") {
      event.preventDefault();

      const prevCursor = getPrevCursor(
        cursor ?? getInitialCursor(),
        getRows(),
        canSelectSection,
      );

      setCursor(prevCursor);
      return;
    }

    if (event.key === "ArrowDown") {
      event.preventDefault();

      const nextCursor = getNextCursor(
        cursor ?? getInitialCursor(),
        getRows(),
        canSelectSection,
      );

      setCursor(nextCursor);
      return;
    }

    if (event.key === "Enter") {
      if (!cursor) {
        return;
      }

      const isSection = cursor.sectionIndex != null && cursor.itemIndex == null;

      if (!isSection) {
        const item =
          cursor.itemIndex != null
            ? sections[cursor.sectionIndex]?.items?.[cursor.itemIndex]
            : null;

        if (item) {
          onChange?.(item);
        }
        return;
      }

      toggleSection(cursor.sectionIndex);
    }
  };

  const canToggleSections = () => {
    return alwaysTogglable || sections.length > 1;
  };

  const isRowSelected = (row: Row<TItem, TSection>) => {
    if (!cursor) {
      return false;
    }

    const { sectionIndex, itemIndex } = cursor;
    return (
      row.sectionIndex === sectionIndex &&
      ("itemIndex" in row ? row.itemIndex === itemIndex : itemIndex == null)
    );
  };

  const isSectionExpanded = (sectionIndex: number) => {
    const openSec = getOpenSection();

    return Boolean(
      alwaysExpanded ||
        openSec === sectionIndex ||
        (globalSearch && searchText.length > 0),
    );
  };

  const rows = getRows();
  const searchRowIndex = rows.findIndex((row) => row.type === "search");
  const hasSearch = searchRowIndex >= 0;

  return (
    <Box
        id={id}
        className={cx(S.accordionListRoot, className, {
          [S.hasSearch]: hasSearch,
        })}
        ref={listRootRef}
        role="tree"
        onKeyDown={handleKeyDown}
        tabIndex={-1}
        style={{
          width,
          ...style,
        }}
        data-testid={testId}
      >
        {rows.map((row, index) => (
          <AccordionListCell<TItem, TSection>
            key={index}
            {...this.props}
            row={row}
            sections={sections}
            onChange={handleChange}
            searchText={searchText}
            onChangeSearchText={handleChangeSearchText}
            sectionIsExpanded={isSectionExpanded}
            alwaysExpanded={
              alwaysExpanded ||
              (globalSearch && searchText.length > 0)
            }
            canToggleSections={canToggleSections()}
            toggleSection={toggleSection}
            hasCursor={isRowSelected(rows[index])}
          />
        ))}
      </Box>
  );
}

export const AccordionList = AccordionListInternal.bind(instanceContext) as <
  TItem extends Item,
  TSection extends Section<TItem> = Section<TItem>,
>(
  props: Props<TItem, TSection>,
) => React.ReactElement | null;