import classNames from 'classnames';
import React, {type JSX, useCallback, useEffect, useRef, useState} from 'react';
import {FormattedMessage, defineMessages} from 'react-intl';
import type {StatusOK} from '@mattermost/types/client4';
import type {ClientLicense, EnvironmentConfig} from '@mattermost/types/config';
import type {ServerError} from '@mattermost/types/errors';
import type {ServerLimits} from '@mattermost/types/limits';
import type {GetFilteredUsersStatsOpts, UsersStats} from '@mattermost/types/users';
import type {ActionResult} from 'mattermost-redux/types/actions';
import ExternalLink from 'components/external_link';
import AdminHeader from 'components/widgets/admin_console/admin_header';
import {AboutLinks, CloudLinks, LicenseSkus, ModalIdentifiers} from 'utils/constants';
import {isLicenseExpired, isLicenseExpiring, isTrialLicense, licenseSKUWithFirstLetterCapitalized, isEnterpriseLicense} from 'utils/license_utils';
import type {ModalData} from 'types/actions';
import EnterpriseEditionLeftPanel, {messages as enterpriseEditionLeftPanelMessages} from './enterprise_edition/enterprise_edition_left_panel';
import EnterpriseEditionRightPanel from './enterprise_edition/enterprise_edition_right_panel';
import ConfirmLicenseRemovalModal from './modals/confirm_license_removal_modal';
import EELicenseModal from './modals/ee_license_modal';
import UploadLicenseModal from './modals/upload_license_modal';
import RenewLinkCard from './renew_license_card/renew_license_card';
import StarterLeftPanel, {messages as licenseSettingsStarterEditionMessages} from './starter_edition/starter_left_panel';
import StarterRightPanel from './starter_edition/starter_right_panel';
import TeamEditionLeftPanel from './team_edition/team_edition_left_panel';
import TeamEditionRightPanel from './team_edition/team_edition_right_panel';
import TrialBanner from './trial_banner/trial_banner';
import TrialLicenseCard from './trial_license_card/trial_license_card';
import UserSeatAlertBanner from './user_seat_alert_banner';
import './license_settings.scss';

type Props = {
    license: ClientLicense;
    enterpriseReady: boolean;
    upgradedFromTE: boolean;
    totalUsers: number;
    isDisabled: boolean;
    prevTrialLicense: ClientLicense;
    environmentConfig: Partial<EnvironmentConfig>;
    actions: {
        getLicenseConfig: () => void;
        uploadLicense: (file: File) => Promise<ActionResult>;
        removeLicense: () => Promise<ActionResult<boolean, ServerError>>;
        getPrevTrialLicense: () => void;
        upgradeToE0: () => Promise<StatusOK>;
        upgradeToE0Status: () => Promise<{percentage: number; error: string | JSX.Element | null}>;
        isAllowedToUpgradeToEnterprise: () => Promise<ActionResult>;
        restartServer: () => Promise<StatusOK>;
        ping: () => Promise<{status: string}>;
        openModal: <P>(modalData: ModalData<P>) => void;
        getServerLimits: () => Promise<ActionResult<ServerLimits, ServerError>>;
        getFilteredUsersStats: (filters: GetFilteredUsersStatsOpts) => Promise<{
            data?: UsersStats;
            error?: ServerError;
        }>;
    };
};

const messages = defineMessages({
    title: {id: 'admin.license.title', defaultMessage: 'Edition and License'},
});

export const searchableStrings = [
    licenseSettingsStarterEditionMessages.key,
    enterpriseEditionLeftPanelMessages.keyRemove,
    messages.title,
];

const LicenseSettings: React.FC<Props> = ({
    license,
    enterpriseReady,
    upgradedFromTE,
    totalUsers,
    isDisabled,
    prevTrialLicense,
    environmentConfig,
    actions,
}) => {
    const [clickNormalUpgradeBtn, setClickNormalUpgradeBtn] = useState(false);
    const [gettingTrial, setGettingTrial] = useState(false);
    const [gettingTrialError, setGettingTrialError] = useState<string | null>(null);
    const [gettingTrialResponseCode, setGettingTrialResponseCode] = useState<number | null>(null);
    const [restartError, setRestartError] = useState<string | null>(null);
    const [restarting, setRestarting] = useState(false);
    const [upgradeDisabled, setUpgradeDisabled] = useState(false);
    const [upgradeError, setUpgradeError] = useState<string | null>(null);
    const [upgradingPercentage, setUpgradingPercentage] = useState(0);
    const [removing, setRemoving] = useState(false);
    const [serverError, setServerError] = useState<string | null>(null);

    const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const reloadPercentageRef = useRef<() => Promise<void>>();

    const reloadPercentage = useCallback(async () => {
        const {percentage, error} = await actions.upgradeToE0Status();
        if (percentage === 100 || error) {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
                intervalRef.current = null;
            }
        } else if (percentage > 0 && !intervalRef.current) {
            intervalRef.current = setInterval(() => {
                reloadPercentageRef.current?.();
            }, 2000);
        }
        setUpgradingPercentage(percentage || 0);
        setUpgradeError((error as string) || null);
    }, [actions]);

    useEffect(() => {
        reloadPercentageRef.current = reloadPercentage;
    }, [reloadPercentage]);

    useEffect(() => {
        if (enterpriseReady) {
            actions.getPrevTrialLicense();
        } else {
            actions.isAllowedToUpgradeToEnterprise().then(({error}) => {
                setUpgradeDisabled(Boolean(error?.message));
                setUpgradeError(error?.message || null);
                if (!error?.message) {
                    reloadPercentage();
                }
            });
        }
        actions.getLicenseConfig();
        actions.getFilteredUsersStats({include_bots: false, include_deleted: false});
        actions.getServerLimits();

        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, [actions, enterpriseReady, reloadPercentage]);

    const handleChange = () => {
        const element = fileInputRef.current;
        if (element?.files?.length) {
            actions.openModal({
                modalId: ModalIdentifiers.UPLOAD_LICENSE,
                dialogType: UploadLicenseModal,
                dialogProps: {
                    fileObjFromProps: element.files[0],
                },
            });

            // Reset the input value so re-selecting the same file re-fires onChange.
            element.value = '';
        }
    };

    const openEELicenseModal = async () => {
        actions.openModal({
            modalId: ModalIdentifiers.ENTERPRISE_EDITION_LICENSE,
            dialogType: EELicenseModal,
        });
    };

    const handleRemove = async (e: React.MouseEvent<HTMLButtonElement>) => {
        e.preventDefault();

        setRemoving(true);

        const {error} = await actions.removeLicense();
        if (error) {
            setServerError(error.message);
            setRemoving(false);
            return;
        }

        await Promise.all([
            actions.getPrevTrialLicense(),
            actions.getLicenseConfig(),
        ]);

        await actions.getServerLimits();

        setServerError(null);
        setRemoving(false);
    };

    const confirmLicenseRemoval = async () => {
        actions.openModal({
            modalId: ModalIdentifiers.CONFIRM_LICENSE_REMOVAL,
            dialogType: ConfirmLicenseRemovalModal,
            dialogProps: {handleRemove, currentLicenseSKU: licenseSKUWithFirstLetterCapitalized(license)},
        });
    };

    const handleUpgrade = async (e?: React.MouseEvent<HTMLButtonElement>) => {
        if (e) {
            e.preventDefault();
        }
        if (upgradingPercentage > 0) {
            return;
        }
        try {
            await actions.upgradeToE0();
            setUpgradingPercentage(1);
            await reloadPercentage();
        } catch (error: any) {
            setUpgradeError(error.message);
            setUpgradingPercentage(0);
        }
    };

    const checkRestarted = useCallback(() => {
        actions.ping().then(() => {
            window.location.reload();
        }).catch(() => {
            setTimeout(checkRestarted, 1000);
        });
    }, [actions]);

    const handleRestart = async (e?: React.MouseEvent<HTMLButtonElement>) => {
        if (e) {
            e.preventDefault();
        }
        setRestarting(true);
        try {
            await actions.restartServer();
        } catch (err) {
            setRestarting(false);
            setRestartError(err as string);
        }
        setTimeout(checkRestarted, 1000);
    };

    const currentPlan = (
        <div className='current-plan-legend'>
            <i className='icon-check-circle'/>
            {'Current Plan'}
        </div>
    );

    const createLink = (link: string, text: string) => {
        return (
            <ExternalLink
                location='license_settings'
                id='privacyLink'
                href={link}
            >
                {text}
            </ExternalLink>
        );
    };

    const termsAndPolicy = (
        <div className='terms-and-policy'>
            {'See also '}
            {createLink(AboutLinks.TERMS_OF_SERVICE, 'Enterprise Edition Terms of Use')}
            {' and '}
            {createLink(AboutLinks.PRIVACY_POLICY, 'Privacy Policy')}
        </div>
    );

    const comparePlans = (license.SkuShortName === LicenseSkus.Entry ? null : (
        <div className='compare-plans-text'>
            {'Curious about upgrading? '}
            {createLink(CloudLinks.PRICING, 'Compare Plans')}
        </div>
    ));

    const renewLicenseCard = () => {
        if (isTrialLicense(license)) {
            return (
                <TrialLicenseCard
                    license={license}
                />
            );
        }
        if (isLicenseExpired(license) || isLicenseExpiring(license)) {
            return (
                <RenewLinkCard
                    license={license}
                    isLicenseExpired={isLicenseExpired(license)}
                    totalUsers={totalUsers}
                />
            );
        }
        return null;
    };

    let leftPanel: React.ReactNode = null;
    let rightPanel: React.ReactNode = null;

    if (!enterpriseReady) { // Team Edition
        // Note: DO NOT LOCALISE THESE STRINGS. Legally we can not since the license is in English.
        leftPanel = (
            <TeamEditionLeftPanel
                openEELicenseModal={openEELicenseModal}
            />
        );

        rightPanel = (
            <TeamEditionRightPanel
                upgradingPercentage={upgradingPercentage}
                upgradeError={upgradeError}
                restartError={restartError}
                handleRestart={handleRestart}
                handleUpgrade={handleUpgrade}
                restarting={restarting}
                openEEModal={openEELicenseModal}
                setClickNormalUpgradeBtn={() => setClickNormalUpgradeBtn(true)}
                upgradeDisabled={upgradeDisabled}
            />
        );
    } else if (license.IsLicensed === 'true') {
        // Note: DO NOT LOCALISE THESE STRINGS. Legally we can not since the license is in English.
        leftPanel = (
            <EnterpriseEditionLeftPanel
                openEELicenseModal={openEELicenseModal}
                upgradedFromTE={upgradedFromTE}
                license={license}
                isTrialLicense={isTrialLicense(license)}
                handleRemove={confirmLicenseRemoval}
                isDisabled={isDisabled}
                removing={removing}
                fileInputRef={fileInputRef}
                handleChange={handleChange}
                statsActiveUsers={totalUsers || 0}
                isLicenseSetByEnvVar={Boolean(environmentConfig?.ServiceSettings?.LicenseFileLocation)}
            />
        );

        rightPanel = (
            <EnterpriseEditionRightPanel
                isTrialLicense={isTrialLicense(license)}
                license={license}
            />
        );
    } else {
        // Note: DO NOT LOCALISE THESE STRINGS. Legally we can not since the license is in English.
        // This is Mattermost Starter (Already downloaded the binary but no license has been set, or ended the trial period)
        leftPanel = (
            <StarterLeftPanel
                openEELicenseModal={openEELicenseModal}
                currentPlan={currentPlan}
                upgradedFromTE={upgradedFromTE}
                fileInputRef={fileInputRef}
                handleChange={handleChange}
            />
        );

        rightPanel = (
            <StarterRightPanel/>
        );
    }

    return (
        <div className='wrapper--fixed'>
                <AdminHeader>
                    <FormattedMessage {...messages.title}/>
                </AdminHeader>
                <div className='admin-console__wrapper'>
                    <div className='admin-console__content'>
                        <div className='admin-console__banner_section'>
                            <UserSeatAlertBanner
                                license={license}
                                totalUsers={totalUsers}
                                location='license_settings'
                            />
                            {!clickNormalUpgradeBtn && (license.IsLicensed !== 'true') &&
                                prevTrialLicense?.IsLicensed !== 'true' &&
                                <TrialBanner
                                    isDisabled={isDisabled}
                                    gettingTrialResponseCode={gettingTrialResponseCode}
                                    gettingTrialError={gettingTrialError}
                                    gettingTrial={gettingTrial}
                                    enterpriseReady={enterpriseReady}
                                    upgradingPercentage={upgradingPercentage}
                                    handleUpgrade={handleUpgrade}
                                    upgradeError={upgradeError}
                                    restartError={restartError}
                                    handleRestart={handleRestart}
                                    restarting={restarting}
                                    openEEModal={openEELicenseModal}
                                    upgradeDisabled={upgradeDisabled}
                                />
                            }
                            {renewLicenseCard()}
                        </div>
                        <div className='top-wrapper'>
                            <div className='left-panel'>
                                <div className='panel-card'>
                                    {leftPanel}
                                </div>
                                {(!isTrialLicense(license)) && termsAndPolicy}
                            </div>
                            <div className='right-panel'>
                                <div className={classNames('panel-card', {entry: license.SkuShortName === LicenseSkus.Entry})}>
                                    {rightPanel}
                                </div>
                                {!isEnterpriseLicense(license) && comparePlans}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
    );
};

export default LicenseSettings;