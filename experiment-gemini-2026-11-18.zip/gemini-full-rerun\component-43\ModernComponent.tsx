import cx from "classnames";
import React, {
  type CSSProperties,
  type ComponentType,
  type ErrorInfo,
  type JSX,
  type ReactNode,
  type Ref,
  Suspense,
  forwardRef,
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { t } from "ttag";
import _ from "underscore";
import ErrorBoundary from "metabase/common/components/ErrorBoundary";
import { SmallGenericError } from "metabase/common/components/ErrorPages";
import { ExplicitSize } from "metabase/common/components/ExplicitSize";
import type { ContentTranslationFunction } from "metabase/content-translation/types";
import CS from "metabase/css/core/index.css";
import { isEmbeddingSdk } from "metabase/embedding-sdk/config";
import type { CardQuestionBuilder } from "metabase/metadata-store";
import { selectQuestionFromCardBuilder } from "metabase/metadata-store";
import { PLUGIN_CUSTOM_VIZ } from "metabase/plugins";
import { connect } from "metabase/redux";
import { getIsDownloadingToImage } from "metabase/redux/downloads";
import type { Dispatch, State } from "metabase/redux/store";
import type { Path } from "metabase/router";
import { getTokenFeature } from "metabase/settings";
import { getFont } from "metabase/styled-components/selectors";
import { Box, Flex, type IconProps, Stack } from "metabase/ui";
import { isQuestionCard } from "metabase/utils/dashboard";
import { formatNumber } from "metabase/utils/formatting";
import { memoize } from "metabase/utils/memoize";
import { getVisualizationComponent } from "metabase/visualizations";
import ChartCaption from "metabase/visualizations/components/ChartCaption";
import ChartTooltip from "metabase/visualizations/components/ChartTooltip";
import { ConnectedClickActionsPopover } from "metabase/visualizations/components/ClickActions";
import { performDefaultAction } from "metabase/visualizations/lib/action";
import { hasNoResults } from "metabase/visualizations/lib/no-results";
import {
  type CardSlownessStatus,
  type ClickActionsMode,
  type ClickObject,
  type OnBrush,
  type VisualizationPassThroughProps,
  isRegularClickAction,
} from "metabase/visualizations/types";
import {
  ChartSettingsError,
  type HighlightedObject,
  type HoveredObject,
  MinRowsError,
  type VisualizationDefinition,
  type VisualizationGridSize,
  extractRemappings,
  getCardKey,
  getComputedSettingsForSeries,
  getVisualizationTransformed,
  isSameSeries,
  prefetchVisualizationComponent,
} from "metabase/viz-core";
import Question from "metabase-lib/v1/Question";
import type {
  CardId,
  Dashboard,
  DashboardCard,
  IconName,
  RawSeries,
  Series,
  SeriesCard,
  SingleSeries,
  TimelineEvent,
  TimelineEventsVisibility,
  VirtualCard,
  VisualizationSettings,
} from "metabase-types/api";
import { isVisualizerDashboardCard } from "metabase-types/guards/dashboard";
import { EmptyVizState } from "../EmptyVizState";
import ChartSettingsErrorButton from "./ChartSettingsErrorButton";
import { ErrorView } from "./ErrorView";
import LoadingView, { type LoadingViewProps } from "./LoadingView";
import { DashCardLoadingView } from "./LoadingView/DashCardLoadingView";
import NoResultsView from "./NoResultsView";
import { VisualizationRenderedWrapper } from "./VisualizationRenderedWrapper";
import { VisualizationRunningState } from "./VisualizationRunningState";
import { Watermark } from "./Watermark";

type StateDispatchProps = {
  dispatch: Dispatch;
};

type StateProps = {
  buildQuestion: CardQuestionBuilder;
  hasDevWatermark: boolean;
  fontFamily: string;
  isEmbeddingSdk: boolean;
  isDownloadingToImage: boolean;
};

type ForwardedRefProps = {
  forwardedRef: Ref<HTMLDivElement>;
};

type OnChangeCardAndRunOpts = {
  nextCard: SeriesCard;
  previousCard: SeriesCard;
  objectId?: number;
  drillName?: string;
};

type VisualizationRawSeries = (
  | SingleSeries
  | {
      card: SeriesCard | VirtualCard;
    }
)[];

type VisualizationOwnProps = {
  actionButtons?: ReactNode | null;
  className?: string;
  dashboard?: Dashboard;
  dashcard?: DashboardCard;
  error?: ReactNode;
  errorIcon?: IconName;
  errorMessageOverride?: string;
  expectedDuration?: number;
  getExtraDataForClick?: (
    clicked: ClickObject | null,
  ) => Record<string, unknown>;
  getHref?: () => string | undefined;
  getCardHref?: (nextCard: SeriesCard) => string | undefined;
  gridSize?: VisualizationGridSize;
  gridUnit?: number;
  handleVisualizationClick?: (clicked: ClickObject | null) => void;
  highlighted?: HighlightedObject | null;
  headerIcon?: IconProps;
  width?: number | null;
  height?: number | null;
  isAction?: boolean;
  isDashboard?: boolean;
  isDocument?: boolean;
  isMetricsViewer?: boolean;
  isMobile?: boolean;
  isRawTable?: boolean;
  isRunning?: boolean;
  isShowingSummarySidebar?: boolean;
  isSlow?: CardSlownessStatus;
  isVisible?: boolean;
  isVisualizer?: boolean;
  scrollToLastColumn?: boolean;
  renderLoadingView?: (props: LoadingViewProps) => JSX.Element | null;
  /** Shown while a custom viz plugin loads. Documents supply their card-embed loading view here. */
  customVizLoadingView?: ReactNode;
  mode?: ClickActionsMode;
  editSummary?: () => void;
  rawSeries?: VisualizationRawSeries;
  visualizerRawSeries?: RawSeries;
  replacementContent?: JSX.Element | null;
  selectedTimelineEventIds?: number[];
  settings?: VisualizationSettings;
  showTitle?: boolean;
  showWarnings?: boolean;
  hideLegend?: boolean;
  style?: CSSProperties;
  timelineEvents?: TimelineEvent[];
  timelineEventsVisibility?: TimelineEventsVisibility;
  onTimelineEventsShown?: () => void;
  onTimelineEventsEnabledChange?: (isEnabled: boolean) => void;
  tc?: ContentTranslationFunction;
  zoomedRowIndex?: number;
  onZoomRow?: (rowIndex: number) => void;
  onOpenChartSettings?: (data: {
    initialChartSettings?: { section: string };
    showSidebarTitle?: boolean;
  }) => void;
  onChangeCardAndRun?: ((opts: OnChangeCardAndRunOpts) => void) | null;
  onBrush?: OnBrush | null;
  onHeaderColumnReorder?: (columnIndex: number) => void;
  onChangeLocation?: (location: Location) => void;
  onUpdateQuestion?: (question: Question) => void;
  onUpdateVisualizationSettings?: (
    settings: VisualizationSettings,
    question?: Question,
  ) => void;
  onUpdateWarnings?: (warnings: string[]) => void;
  onVisualizationRendered?: (series: Series) => void;
  onSameOriginNavigation?: (location: Partial<Path>) => void;
  /** When true, internal click behaviors (dashboard/question links) are preserved */
  enableEntityNavigation?: boolean;
} & VisualizationPassThroughProps;

type VisualizationProps = StateDispatchProps &
  StateProps &
  ForwardedRefProps &
  VisualizationOwnProps;

const mapStateToProps = (state: State): StateProps => ({
  buildQuestion: selectQuestionFromCardBuilder(state),
  hasDevWatermark: getTokenFeature(state, "development_mode"),
  fontFamily: getFont(state),
  isEmbeddingSdk: isEmbeddingSdk(),
  isDownloadingToImage: getIsDownloadingToImage(state),
});

const SMALL_CARD_WIDTH_THRESHOLD = 150;

const isLoading = (series: Series | null) => {
  return !(
    series &&
    series.length > 0 &&
    _.every(
      series,
      (s) => !!s.data || _.isObject(s.card.visualization_settings.virtual_card),
    )
  );
};

const deriveStateFromProps = (props: VisualizationProps) => {
  const rawSeriesArray = props.rawSeries || [];
  const firstCard = rawSeriesArray[0]?.card;
  const firstQuestion = firstCard != null ? new Question(firstCard) : undefined;
  const isNativeView =
    props.queryBuilderMode === "view" && firstQuestion?.isNative();

  const transformed = props.rawSeries
    ? getVisualizationTransformed(
        // Unjustified type cast. FIXME
        extractRemappings(props.rawSeries as RawSeries),
      )
    : null;

  const series = transformed?.series ?? null;

  const computedSettings = !isLoading(series)
    ? getComputedSettingsForSeries(series, {
        enableEntityNavigation: props.enableEntityNavigation,
      })
    : {};

  return {
    series,
    computedSettings,
    visualization: transformed?.visualization ?? null,
    isNativeView: !!isNativeView,
  };
};

const findCardById = (
  cardId?: CardId | null,
  dashcard?: DashboardCard,
  rawSeries: VisualizationRawSeries = [],
  visualizerRawSeries: RawSeries = [],
) => {
  const isVisualizerDashCard = isVisualizerDashboardCard(dashcard);
  const lookupSeries = isVisualizerDashCard ? visualizerRawSeries : rawSeries;
  return (
    lookupSeries.find((series) => series.card.id === cardId)?.card ??
    lookupSeries[0]?.card
  );
};

const defaultOnChangeLocation = (location: Location) => {
  // Unjustified type cast. FIXME
  window.location = location as any;
};

function Visualization(props: VisualizationProps) {
  const {
    actionButtons,
    buildQuestion,
    canToggleSeriesVisibility,
    className,
    dashboard,
    dashcard,
    dispatch,
    editSummary,
    enableEntityNavigation,
    error: propError,
    errorIcon,
    errorMessageOverride,
    expectedDuration,
    fontFamily,
    forwardedRef,
    getCardHref,
    getExtraDataForClick = () => ({}),
    getHref,
    handleVisualizationClick: handleVisualizationClickProp,
    hasColumnReordering,
    hasDevWatermark,
    headerIcon,
    height: propHeight = 0,
    hideLegend,
    highlighted,
    isAction = false,
    isDashboard = false,
    isDocument = false,
    isDownloadingToImage = false,
    isEditing = false,
    isEmbeddingSdk = false,
    isFullscreen = false,
    isMetricsViewer = false,
    isMobile = false,
    isObjectDetail,
    isPreviewing = false,
    isQueryBuilder = false,
    isRawTable = false,
    isSelectable,
    isSettings = false,
    isShowingDetailsOnlyColumns,
    isShowingSummarySidebar,
    isSlow,
    isSortable,
    isStandaloneQuestion,
    isRunning,
    isVisible,
    isVisualizer,
    mode,
    onAllSelectClick,
    onBrush,
    onChangeCardAndRun,
    onChangeLocation = defaultOnChangeLocation,
    onDeselectTimelineEvents,
    onHeaderColumnReorder,
    onOpenChartSettings,
    onOpenTimelines,
    onRowSelectClick,
    onSameOriginNavigation,
    onSeeAllEvents,
    onSelectTimelineEvents,
    onSortingChange,
    onTimelineEventsEnabledChange,
    onTimelineEventsShown,
    onTogglePreviewing,
    onUpdateQuestion,
    onUpdateVisualizationSettings = () => {},
    onUpdateWarnings,
    onVisualizationRendered,
    onZoomRow,
    queryBuilderMode,
    rawSeries = [],
    renderEmptyMessage,
    renderLoadingView = LoadingView,
    renderTableHeader,
    replacementContent,
    rowChecked,
    scrollToColumn,
    scrollToLastColumn,
    selectedTimelineEventIds,
    settings: propSettings,
    showAllLegendItems,
    showTitle = false,
    showWarnings,
    sorting,
    style,
    tableFooterExtraButtons,
    tableHeaderHeight,
    tc,
    timelineEvents,
    timelineEventsVisibility,
    titleMenuItems,
    totalNumGridCols,
    transformClickObject,
    visualizerRawSeries = [],
    width: propWidth = 0,
    zoomedRowIndex,
  } = props;

  const [clicked, setClicked] = useState<ClickObject | null>(null);
  const [stateHovered, setHovered] = useState<HoveredObject | null>(null);
  const [stateError, setStateError] = useState<ReactNode>(null);
  const [genericError, setGenericError] = useState<ErrorInfo | null>(null);
  const [warnings, setWarnings] = useState<string[]>([]);
  const [derivedState, setDerivedState] = useState(() =>
    deriveStateFromProps(props),
  );
  const [prevTriggerProps, setPrevTriggerProps] = useState(() => ({
    rawSeries: props.rawSeries,
    settings: props.settings,
    timelineEvents: props.timelineEvents,
    selectedTimelineEventIds: props.selectedTimelineEventIds,
    enableEntityNavigation: props.enableEntityNavigation,
    queryBuilderMode: props.queryBuilderMode,
  }));

  const resetHoverTimerRef = useRef<number | null>(null);

  useEffect(() => {
    return () => {
      if (resetHoverTimerRef.current !== null) {
        clearTimeout(resetHoverTimerRef.current);
      }
    };
  }, []);

  if (
    !isSameSeries(rawSeries, prevTriggerProps.rawSeries) ||
    !_.isEqual(propSettings, prevTriggerProps.settings) ||
    !_.isEqual(timelineEvents, prevTriggerProps.timelineEvents) ||
    !_.isEqual(
      selectedTimelineEventIds,
      prevTriggerProps.selectedTimelineEventIds,
    ) ||
    enableEntityNavigation !== prevTriggerProps.enableEntityNavigation ||
    queryBuilderMode !== prevTriggerProps.queryBuilderMode
  ) {
    setPrevTriggerProps({
      rawSeries,
      settings: propSettings,
      timelineEvents,
      selectedTimelineEventIds,
      enableEntityNavigation,
      queryBuilderMode,
    });
    setDerivedState(deriveStateFromProps(props));
    setHovered(null);
    setStateError(null);
    setGenericError(null);
    setWarnings([]);
  }

  const { series, computedSettings, visualization, isNativeView } =
    derivedState;

  useEffect(() => {
    if (visualization) {
      prefetchVisualizationComponent(visualization.identifier);
    }
  }, [visualization]);

  const getWarnings = useCallback(
    (currentWarnings: string[] = warnings) => {
      let result = currentWarnings || [];
      if (
        series &&
        series[0]?.card?.display !== "table" &&
        series[0]?.card?.display !== "list"
      ) {
        result = result.concat(
          rawSeries
            .filter(
              (s): s is SingleSeries =>
                "data" in s && s.data && s.data.rows_truncated != null,
            )
            .map(
              (s) =>
                t`Data truncated to ${formatNumber(s.data.rows_truncated)} rows.`,
            ),
        );
      }
      return result;
    },
    [rawSeries, series, warnings],
  );

  const prevWarningsRef = useRef<string[]>();
  useEffect(() => {
    const currentWarnings = getWarnings();
    if (!_.isEqual(prevWarningsRef.current, currentWarnings)) {
      prevWarningsRef.current = currentWarnings;
      onUpdateWarnings?.(currentWarnings || []);
    }
  }, [getWarnings, onUpdateWarnings]);

  const handleHoverChange = useCallback(
    (nextHovered: HoveredObject | null | undefined) => {
      if (nextHovered) {
        setHovered(nextHovered);
        if (resetHoverTimerRef.current !== null) {
          clearTimeout(resetHoverTimerRef.current);
          resetHoverTimerRef.current = null;
        }
      } else {
        resetHoverTimerRef.current = window.setTimeout(() => {
          setHovered(null);
          resetHoverTimerRef.current = null;
        }, 0);
      }
    },
    [],
  );

  const getClickActionsCachedRef = useRef(
    memoize(
      (
        clickedObject: ClickObject | null | undefined,
        currentMode: ClickActionsMode | undefined,
        currentComputedSettings: Record<string, string>,
        currentDashcard: DashboardCard | undefined,
        currentBuildQuestion: CardQuestionBuilder,
        currentRawSeries: VisualizationRawSeries = [],
        currentVisualizerRawSeries: RawSeries = [],
        currentIsRawTable = false,
        currentGetExtraDataForClick: (
          clicked: ClickObject | null,
        ) => Record<string, unknown> = () => ({}),
        currentTransformClickObject?: (clicked: ClickObject) => ClickObject,
      ) => {
        if (!clickedObject) {
          return [];
        }

        const transformedClick = currentTransformClickObject
          ? currentTransformClickObject(clickedObject)
          : clickedObject;

        const card = findCardById(
          transformedClick.cardId,
          currentDashcard,
          currentRawSeries,
          currentVisualizerRawSeries,
        );
        if (!isQuestionCard(card)) {
          return [];
        }
        const question = currentBuildQuestion(card);

        return currentMode
          ? currentMode.actionsForClick(
              {
                ...transformedClick,
                extraData: {
                  ...currentGetExtraDataForClick(transformedClick),
                  isRawTable: currentIsRawTable,
                },
              },
              { question, settings: currentComputedSettings },
            )
          : [];
      },
    ),
  );

  const getClickActions = useCallback(
    (clickedObject?: ClickObject | null) => {
      return getClickActionsCachedRef.current(
        clickedObject,
        mode,
        computedSettings,
        dashcard,
        buildQuestion,
        rawSeries,
        visualizerRawSeries,
        isRawTable,
        getExtraDataForClick,
        transformClickObject,
      );
    },
    [
      mode,
      computedSettings,
      dashcard,
      buildQuestion,
      rawSeries,
      visualizerRawSeries,
      isRawTable,
      getExtraDataForClick,
      transformClickObject,
    ],
  );

  const handleOnChangeCardAndRun = useCallback(
    ({
      nextCard,
      objectId,
      drillName,
    }: Pick<OnChangeCardAndRunOpts, "nextCard" | "objectId" | "drillName">) => {
      const previousCard = findCardById(
        nextCard?.id,
        dashcard,
        rawSeries,
        visualizerRawSeries,
      );

      if (isQuestionCard(previousCard)) {
        onChangeCardAndRun?.({
          previousCard,
          nextCard,
          objectId,
          drillName,
        });
      }
    },
    [dashcard, rawSeries, visualizerRawSeries, onChangeCardAndRun],
  );

  const visualizationIsClickable = useCallback(
    (clickedObject: ClickObject | null) => {
      if (!clickedObject) {
        return false;
      }

      try {
        return getClickActions(clickedObject).length > 0;
      } catch (e) {
        console.warn(e);
        return false;
      }
    },
    [getClickActions],
  );

  const handleVisualizationClick = useCallback(
    (clickedObject: ClickObject | null) => {
      if (typeof handleVisualizationClickProp === "function") {
        handleVisualizationClickProp(clickedObject);
        return;
      }

      const didPerformDefaultAction = performDefaultAction(
        getClickActions(clickedObject),
        {
          dispatch,
          onChangeCardAndRun: handleOnChangeCardAndRun,
          onSameOriginNavigation,
        },
      );

      if (didPerformDefaultAction) {
        return;
      }

      // needs to be delayed so we don't clear it when switching from one drill through to another
      setTimeout(() => {
        setClicked(clickedObject);
      }, 100);
    },
    [
      handleVisualizationClickProp,
      getClickActions,
      dispatch,
      handleOnChangeCardAndRun,
      onSameOriginNavigation,
    ],
  );

  const onRender = useCallback(
    ({ warnings: newWarnings = [] }: { warnings?: string[] } = {}) => {
      requestAnimationFrame(() => {
        setWarnings((currentWarnings) => {
          if (!_.isEqual(currentWarnings, newWarnings)) {
            return newWarnings;
          }
          return currentWarnings;
        });
      });
    },
    [],
  );

  const onRenderError = useCallback((errorMsg: string | undefined) => {
    console.error(errorMsg);
    setStateError(errorMsg);
  }, []);

  const onErrorBoundaryError = useCallback(
    (boundaryError: ErrorInfo) => {
      setGenericError(boundaryError);
    },
    [],
  );

  const hideActions = useCallback(() => {
    setClicked(null);
  }, []);

  const handleVisualizationRendered = useCallback(() => {
    if (series) {
      onVisualizationRendered?.(series);
    }
  }, [series, onVisualizationRendered]);

  const width = propWidth ?? 0;
  const height = propHeight ?? 0;

  const CardVisualization = visualization
    ? getVisualizationComponent(visualization.identifier)
    : undefined;
  const small = width < SMALL_CARD_WIDTH_THRESHOLD;

  let hovered = stateHovered;

  const clickActions = getClickActions(clicked);
  const regularClickActions = clickActions.filter(isRegularClickAction);

  // disable hover when click action is active
  if (clickActions.length > 0) {
    hovered = null;
  }

  // disable hover when exporting chart as an image (png download)
  if (isDownloadingToImage) {
    hovered = null;
  }

  let error = propError || stateError;
  let noResults = false;
  let isPlaceholder = false;
  const loading = isLoading(series);

  // don't try to load settings unless data is loaded
  const settings = propSettings || computedSettings;

  if (!loading && !error) {
    if (!visualization || !CardVisualization) {
      error = t`Could not find visualization`;
    } else {
      try {
        if (visualization.checkRenderable && series) {
          visualization.checkRenderable(series, settings);
        }
      } catch (e: unknown) {
        error =
          // Unjustified type cast. FIXME
          (e as Error).message ||
          t`Could not display this chart with this data.`;
        if (
          e instanceof ChartSettingsError &&
          visualization?.hasEmptyState &&
          !isDashboard &&
          !isMetricsViewer &&
          // For the SDK the EmptyVizState component in some cases (a small container) looks really weird,
          // so at least temporarily we don't display it when rendered in the SDK.
          !isEmbeddingSdk
        ) {
          // hide the error and display the empty state instead
          error = null;
          isPlaceholder = true;
        } else if (e instanceof ChartSettingsError && onOpenChartSettings) {
          error = (
            <ChartSettingsErrorButton
              message={error}
              buttonLabel={e.buttonText}
              onClick={() =>
                onOpenChartSettings({ initialChartSettings: e.initial })
              }
            />
          );
        } else if (e instanceof MinRowsError) {
          noResults = true;
        }
      }
    }
  }

  if (!error && !genericError && series) {
    noResults = _.every(series, (s) => s && s.data && hasNoResults(s.data));
  }

  const extra = (
    <Flex component="span" align="center">
      {actionButtons}
    </Flex>
  );

  let { gridSize, gridUnit } = props;
  if (
    !gridSize &&
    gridUnit &&
    // Check that width/height are set. If they're not, we want to pass
    // undefined rather than {width: 0, height: 0}. Passing 0 will hide axes.
    width != null &&
    height != null
  ) {
    gridSize = {
      width: Math.round(width / (gridUnit * 4)),
      height: Math.round(height / (gridUnit * 3)),
    };
  }

  const isVisualizerDashCard = isVisualizerDashboardCard(dashcard);

  const title = settings["card.title"];
  const hasHeaderContent = title || extra;
  const isHeaderEnabled = !(visualization && visualization.noHeader);
  const isLoadingHeaderEnabled = !(
    visualization && visualization.noLoadingHeader
  );

  const hasHeader =
    (showTitle &&
      hasHeaderContent &&
      ((loading && isLoadingHeaderEnabled) ||
        error ||
        noResults ||
        isHeaderEnabled)) ||
    (replacementContent && (dashcard?.size_y !== 1 || isMobile) && !isAction);

  // We can't navigate a user to a particular card from a visualizer viz,
  // so title selection is disabled in this case
  const canSelectTitle =
    onChangeCardAndRun &&
    !replacementContent &&
    (!isVisualizerDashCard || React.Children.count(titleMenuItems) === 1);

  return (
    <ErrorBoundary
        onError={onErrorBoundaryError}
        ref={forwardedRef}
      >
        <Stack
          // A class, not h="100%": callers override the height through style
          className={cx(CS.fullHeight, className)}
          style={style}
          gap={0}
          data-testid="visualization-root"
          // `getUiName` should be defined (and is a required field on the TS type), but because we have javascript
          // files about visualizations, it's best if we don't risk crashing the app, hence the `?.()`
          data-viz-ui-name={visualization?.getUiName?.()}
          ref={forwardedRef}
        >
          {!!hasHeader && (
            <Box pt="0.625rem" px="sm" pb="xs" flex="0 0 auto">
              <ChartCaption
                series={series}
                visualizerRawSeries={visualizerRawSeries}
                settings={settings}
                icon={headerIcon}
                actionButtons={extra}
                hasInfoTooltip={!isDashboard || !isEditing}
                titleMenuItems={titleMenuItems}
                width={width}
                getHref={getHref}
                onChangeCardAndRun={
                  canSelectTitle ? handleOnChangeCardAndRun : null
                }
              />
            </Box>
          )}
          {replacementContent ? (
            replacementContent
          ) : (isDashboard || isMetricsViewer) && noResults ? (
            <NoResultsView isSmall={small} />
          ) : error && !isRunning ? (
            <ErrorView
              error={errorMessageOverride ?? error}
              icon={errorIcon}
              isSmall={small}
              isDashboard={!!isDashboard}
            />
          ) : genericError ? (
            <SmallGenericError bordered={false} />
          ) : loading ? (
            renderLoadingView({
              expectedDuration,
              isSlow,
            })
          ) : isPlaceholder ? (
            <EmptyVizState
              chartType={visualization?.identifier}
              isSummarizeSidebarOpen={isShowingSummarySidebar}
              editSummary={isDashboard ? undefined : editSummary}
              isNativeView={isNativeView}
            />
          ) : (
            series &&
            CardVisualization && (
              <div
                data-card-key={getCardKey(series[0].card?.id)}
                className={cx(CS.flex, CS.flexColumn, CS.flexFull)}
                style={{ position: hasDevWatermark ? "relative" : undefined }}
              >
                {/* The same view the card shows while its data loads, so a
                    chunk that arrives after the data does not swap one
                    loading state for a different one. */}
                <Suspense
                  fallback={renderLoadingView({ expectedDuration, isSlow })}
                >
                  <VisualizationRenderedWrapper
                    onRendered={handleVisualizationRendered}
                  >
                    <CardVisualization
                      actionButtons={actionButtons}
                      // NOTE: CardVisualization class used as a selector for tests
                      className={cx(
                        "CardVisualization",
                        CS.flexFull,
                        CS.flexBasisNone,
                      )}
                      card={series[0].card} // convenience for single-series visualizations
                      canToggleSeriesVisibility={canToggleSeriesVisibility}
                      clicked={clicked}
                      data={series[0].data} // convenience for single-series visualizations
                      dashboard={dashboard}
                      dashcard={dashcard}
                      dispatch={dispatch}
                      errorIcon={errorIcon}
                      fontFamily={fontFamily}
                      getExtraDataForClick={getExtraDataForClick}
                      getHref={getHref}
                      getCardHref={getCardHref}
                      gridSize={gridSize}
                      hasColumnReordering={hasColumnReordering}
                      headerIcon={hasHeader ? null : headerIcon}
                      height={height}
                      hovered={hovered}
                      highlighted={highlighted}
                      isDashboard={!!isDashboard}
                      isDocument={!!isDocument}
                      isEditing={!!isEditing}
                      isEmbeddingSdk={isEmbeddingSdk}
                      isFullscreen={!!isFullscreen}
                      isMetricsViewer={!!isMetricsViewer}
                      isMobile={!!isMobile}
                      isVisualizer={!!isVisualizer}
                      isVisualizerCard={isVisualizerDashCard}
                      isObjectDetail={isObjectDetail}
                      isPreviewing={isPreviewing}
                      isRawTable={isRawTable}
                      isQueryBuilder={!!isQueryBuilder}
                      isStandaloneQuestion={!!isStandaloneQuestion}
                      isSettings={!!isSettings}
                      isShowingDetailsOnlyColumns={isShowingDetailsOnlyColumns}
                      scrollToLastColumn={scrollToLastColumn}
                      mode={mode}
                      queryBuilderMode={queryBuilderMode}
                      // Unjustified type cast. FIXME
                      rawSeries={rawSeries as RawSeries}
                      visualizerRawSeries={visualizerRawSeries}
                      renderEmptyMessage={renderEmptyMessage}
                      renderTableHeader={renderTableHeader}
                      scrollToColumn={scrollToColumn}
                      selectedTimelineEventIds={selectedTimelineEventIds}
                      series={series}
                      settings={settings}
                      showAllLegendItems={showAllLegendItems}
                      hideLegend={hideLegend}
                      showTitle={!!showTitle}
                      tableHeaderHeight={tableHeaderHeight}
                      timelineEvents={timelineEvents}
                      timelineEventsVisibility={timelineEventsVisibility}
                      onTimelineEventsShown={onTimelineEventsShown}
                      onTimelineEventsEnabledChange={
                        onTimelineEventsEnabledChange
                      }
                      totalNumGridCols={totalNumGridCols}
                      visualizationIsClickable={visualizationIsClickable}
                      width={width}
                      zoomedRowIndex={zoomedRowIndex}
                      onZoomRow={onZoomRow}
                      onActionDismissal={hideActions}
                      onChangeCardAndRun={
                        onChangeCardAndRun
                          ? handleOnChangeCardAndRun
                          : null
                      }
                      onBrush={onBrush}
                      onDeselectTimelineEvents={onDeselectTimelineEvents}
                      onHoverChange={handleHoverChange}
                      onOpenTimelines={onOpenTimelines}
                      onRender={onRender}
                      onRenderError={onRenderError}
                      onSelectTimelineEvents={onSelectTimelineEvents}
                      onSeeAllEvents={onSeeAllEvents}
                      onTogglePreviewing={onTogglePreviewing}
                      onUpdateVisualizationSettings={
                        onUpdateVisualizationSettings
                      }
                      onUpdateWarnings={onUpdateWarnings}
                      onVisualizationClick={handleVisualizationClick}
                      onHeaderColumnReorder={onHeaderColumnReorder}
                      titleMenuItems={hasHeader ? undefined : titleMenuItems}
                      tableFooterExtraButtons={tableFooterExtraButtons}
                      // These props are only used by the table on the Erroring Questions admin page
                      isSelectable={isSelectable}
                      rowChecked={rowChecked}
                      onAllSelectClick={onAllSelectClick}
                      onRowSelectClick={onRowSelectClick}
                      isSortable={isSortable}
                      sorting={sorting}
                      onSortingChange={onSortingChange}
                    />
                  </VisualizationRenderedWrapper>
                </Suspense>
                {hasDevWatermark && <Watermark card={series[0].card} />}
              </div>
            )
          )}
          <ChartTooltip hovered={hovered} settings={settings} />
          {onChangeCardAndRun && (
            <ConnectedClickActionsPopover
              clicked={clicked}
              clickActions={regularClickActions}
              onChangeCardAndRun={handleOnChangeCardAndRun}
              onUpdateQuestion={onUpdateQuestion}
              onSameOriginNavigation={onSameOriginNavigation}
              onClose={hideActions}
              series={series}
              onUpdateVisualizationSettings={onUpdateVisualizationSettings}
            />
          )}
        </Stack>
      </ErrorBoundary>
  );
}

export default _.compose(
  connect(mapStateToProps),
  ExplicitSize<VisualizationProps>({
    selector: ".CardVisualization",
    refreshMode: (props) => (props.isVisible ? "throttle" : "debounceLeading"),
  }),
)(
  forwardRef<HTMLDivElement, VisualizationProps>(
    function VisualizationForwardRef(props, ref) {
      const display = props.rawSeries?.[0]?.card?.display;
      const { loading: customVizLoading } =
        PLUGIN_CUSTOM_VIZ.useAutoLoadCustomVizPlugin(display);

      if (customVizLoading) {
        if (props.customVizLoadingView) {
          return <>{props.customVizLoadingView}</>;
        }

        if (props.isDashboard) {
          return (
            <DashCardLoadingView
              display="table"
              expectedDuration={props.expectedDuration}
              isSlow={props.isSlow}
            />
          );
        }

        return <VisualizationRunningState className={cx(CS.spread, CS.z2)} />;
      }

      return <Visualization {...props} forwardedRef={ref} />;
    },
  ),
) as ComponentType<VisualizationOwnProps>;