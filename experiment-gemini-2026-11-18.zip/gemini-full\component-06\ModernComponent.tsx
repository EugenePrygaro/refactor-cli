import React, {type JSX, useEffect, useRef, useState} from 'react';
import type {IntlShape, MessageDescriptor} from 'react-intl';
import {defineMessage, injectIntl} from 'react-intl';
import type {UserProfile} from '@mattermost/types/users';
import type {RelationOneToOne} from '@mattermost/types/utilities';
import type {ActionResult} from 'mattermost-redux/types/actions';
import {filterProfilesStartingWithTerm} from 'mattermost-redux/utils/user_utils';
import MultiSelect from 'components/multiselect/multiselect';
import type {Value} from 'components/multiselect/multiselect';
import Constants from 'utils/constants';
import MultiSelectOption from './multiselect_option/multiselect_option';

const USERS_PER_PAGE = 50;

const MAX_SELECTABLE_VALUES = 256;

type UserProfileValue = Value & UserProfile;

export type Props = {
    multilSelectKey: string;
    userStatuses: RelationOneToOne<UserProfile, string>;
    focusOnLoad?: boolean;

    intl: IntlShape;

    // Used if we are adding new members to an existing group
    groupId?: string;

    // onSubmitCallback takes an array of UserProfiles and should set usersToAdd in state of parent component
    onSubmitCallback: (userProfiles?: UserProfile[]) => Promise<void>;
    addUserCallback?: (userProfiles: UserProfile[]) => void;
    deleteUserCallback?: (userProfiles: UserProfile[]) => void;

    // These are the optinoal search parameters
    searchOptions?: any;

    // Dictionaries of userid mapped users to exclude or include from this list
    excludeUsers?: Record<string, UserProfileValue>;
    includeUsers?: Record<string, UserProfileValue>;

    profiles: UserProfileValue[];

    savingEnabled: boolean;
    saving: boolean;
    buttonSubmitText?: string | MessageDescriptor;
    buttonSubmitLoadingText?: string | MessageDescriptor;
    backButtonClick?: () => void;
    backButtonText?: string | MessageDescriptor;

    actions: {
        getProfiles: (page?: number, perPage?: number) => Promise<ActionResult>;
        getProfilesNotInGroup: (groupId: string, page?: number, perPage?: number) => Promise<ActionResult>;
        loadStatusesForProfilesList: (users: UserProfile[]) => void;
        searchProfiles: (term: string, options: any) => Promise<ActionResult>;
    };
};

export const AddUserToGroupMultiSelect = ({
    multilSelectKey,
    userStatuses,
    focusOnLoad,
    intl,
    groupId,
    onSubmitCallback,
    addUserCallback,
    deleteUserCallback,
    searchOptions,
    excludeUsers = {},
    includeUsers = {},
    profiles,
    savingEnabled,
    saving,
    buttonSubmitText: customButtonSubmitText,
    buttonSubmitLoadingText: customButtonSubmitLoadingText,
    backButtonClick,
    backButtonText,
    actions,
}: Props): JSX.Element => {
    const [values, setValues] = useState<UserProfileValue[]>([]);
    const [term, setTerm] = useState('');
    const [loadingUsers, setLoadingUsers] = useState(true);

    const searchTimeoutId = useRef(0);
    const selectedItemRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        if (groupId) {
            actions.getProfilesNotInGroup(groupId).then(() => {
                setLoadingUsers(false);
            });
        } else {
            actions.getProfiles().then(() => {
                setLoadingUsers(false);
            });
        }

        actions.loadStatusesForProfilesList(profiles);
    }, [actions, groupId, profiles]);

    useEffect(() => {
        return () => {
            clearTimeout(searchTimeoutId.current);
        };
    }, []);

    const addValue = (value: UserProfileValue): void => {
        const newValues: UserProfileValue[] = Object.assign([], values);
        if (newValues.indexOf(value) === -1) {
            newValues.push(value);
        }

        if (addUserCallback) {
            addUserCallback(newValues);
        }

        setValues(newValues);
    };

    const handleDelete = (newValues: UserProfileValue[]): void => {
        if (deleteUserCallback) {
            deleteUserCallback(newValues);
        }

        setValues(newValues);
    };

    const handlePageChange = (page: number, prevPage: number): void => {
        if (page > prevPage) {
            setLoadingUsers(true);
            if (groupId) {
                actions.getProfilesNotInGroup(groupId, page + 1, USERS_PER_PAGE).then(() => {
                    setLoadingUsers(false);
                });
            } else {
                actions.getProfiles(page + 1, USERS_PER_PAGE).then(() => {
                    setLoadingUsers(false);
                });
            }
        }
    };

    const handleSubmit = (): void => {
        const userIds = values.map((v) => v.id);
        if (userIds.length === 0) {
            return;
        }
        onSubmitCallback(values);
    };

    const search = (searchTerm: string): void => {
        const trimmedTerm = searchTerm.trim();
        clearTimeout(searchTimeoutId.current);
        setTerm(trimmedTerm);

        if (trimmedTerm) {
            setLoadingUsers(true);
            searchTimeoutId.current = window.setTimeout(
                async () => {
                    await actions.searchProfiles(trimmedTerm, searchOptions);
                    setLoadingUsers(false);
                },
                Constants.SEARCH_TIMEOUT_MILLISECONDS,
            );
        }
    };

    const renderAriaLabel = (option: UserProfileValue): string => {
        if (!option) {
            return '';
        }
        return option.username;
    };

    const renderOption = (
        option: UserProfileValue,
        isSelected: boolean,
        onAdd: (user: UserProfileValue) => void,
        onMouseMove: (user: UserProfileValue) => void,
    ) => {
        return (
            <MultiSelectOption
                option={option}
                onAdd={onAdd}
                isSelected={isSelected}
                onMouseMove={onMouseMove}
                userStatuses={userStatuses}
                ref={isSelected ? selectedItemRef : undefined}
                key={option.id}
            />
        );
    };

    const buttonSubmitText = customButtonSubmitText || defineMessage({id: 'multiselect.createGroup', defaultMessage: 'Create Group'});
    const buttonSubmitLoadingText = customButtonSubmitLoadingText || defineMessage({id: 'multiselect.creating', defaultMessage: 'Creating...'});

    let users = filterProfilesStartingWithTerm(profiles, term).filter((user) => {
        return user.delete_at === 0 &&
            (excludeUsers !== undefined && !excludeUsers[user.id]);
    }).map((user) => user as UserProfileValue);

    if (includeUsers) {
        const includeUsersList = Object.values(includeUsers);
        users = [...users, ...includeUsersList];
    }

    let maxValues;
    let numRemainingText = null;

    if (values.length >= MAX_SELECTABLE_VALUES) {
        maxValues = MAX_SELECTABLE_VALUES;
        numRemainingText = defineMessage({id: 'multiselect.maxGroupMembers', defaultMessage: 'No more than 256 members can be added to a group at once.'});
    }

    return (
        <MultiSelect
                key={multilSelectKey}
                options={users}
                optionRenderer={renderOption}
                intl={intl}
                selectedItemRef={selectedItemRef}
                values={values}
                ariaLabelRenderer={renderAriaLabel}
                saveButtonPosition={'bottom'}
                perPage={USERS_PER_PAGE}
                handlePageChange={handlePageChange}
                handleInput={search}
                handleDelete={handleDelete}
                handleAdd={addValue}
                handleSubmit={handleSubmit}
                buttonSubmitText={buttonSubmitText}
                buttonSubmitLoadingText={buttonSubmitLoadingText}
                saving={saving}
                loading={loadingUsers}
                placeholderText={defineMessage({id: 'multiselect.placeholder', defaultMessage: 'Search for people'})}
                valueWithImage={true}
                focusOnLoad={focusOnLoad}
                savingEnabled={savingEnabled}
                backButtonClick={backButtonClick}
                backButtonText={backButtonText}
                maxValues={maxValues}
                numRemainingText={numRemainingText}
                required={true}
            />
    );
};

export default injectIntl(AddUserToGroupMultiSelect);