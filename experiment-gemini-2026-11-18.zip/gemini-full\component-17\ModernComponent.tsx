import debounce from 'lodash/debounce';
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {FormattedMessage} from 'react-intl';
import type {Team, TeamSearchOpts} from '@mattermost/types/teams';
import type {ActionResult} from 'mattermost-redux/types/actions';
import DataGrid from 'components/admin_console/data_grid/data_grid';
import type {Column, Row} from 'components/admin_console/data_grid/data_grid';
import TeamIcon from 'components/widgets/team_icon/team_icon';
import Constants from 'utils/constants';
import * as Utils from 'utils/utils';
import './team_list.scss';

type Props = {
    teams: Team[];
    totalCount: number;
    searchTerm: string;

    policyId?: string;

    onRemoveCallback: (user: Team) => void;
    teamsToRemove: Record<string, Team>;
    teamsToAdd: Record<string, Team>;

    actions: {
        searchTeams: (id: string, term: string, opts: TeamSearchOpts) => Promise<ActionResult>;
        getDataRetentionCustomPolicyTeams: (id: string, page: number, perPage: number) => Promise<ActionResult>;
        setTeamListSearch: (term: string) => ActionResult;
    };
};

const PAGE_SIZE = 10;

export default function TeamList({
    teams,
    totalCount,
    searchTerm,
    policyId,
    onRemoveCallback,
    teamsToRemove,
    teamsToAdd,
    actions,
}: Props) {
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(0);

    const pageLoaded = useRef(0);
    const isMounted = useRef(false);
    const prevSearchTerm = useRef(searchTerm);

    const propsRef = useRef({policyId, searchTerm, actions});
    propsRef.current = {policyId, searchTerm, actions};

    const loadPage = useCallback(async (pageNumber: number, pageSize = PAGE_SIZE) => {
        if (policyId) {
            setLoading(true);
            await actions.getDataRetentionCustomPolicyTeams(policyId, pageNumber, pageSize);
            setLoading(false);
        }
    }, [policyId, actions]);

    const searchDebounced = useMemo(
        () =>
            debounce(async () => {
                const {policyId: currentPolicyId, searchTerm: currentSearchTerm, actions: currentActions} = propsRef.current;

                if (currentPolicyId) {
                    await currentActions.searchTeams(currentPolicyId, currentSearchTerm, {});
                }

                setLoading(false);
            }, Constants.SEARCH_TIMEOUT_MILLISECONDS),
        [],
    );

    useEffect(() => {
        return () => {
            searchDebounced.cancel();
        };
    }, [searchDebounced]);

    useEffect(() => {
        if (!isMounted.current) {
            isMounted.current = true;
            loadPage(0, PAGE_SIZE * 2);
            return;
        }

        if (prevSearchTerm.current !== searchTerm) {
            prevSearchTerm.current = searchTerm;
            setLoading(true);
            if (searchTerm === '') {
                loadPage(1).then(() => {
                    setLoading(false);
                });
                return;
            }
            searchDebounced();
        }
    }, [searchTerm, loadPage, searchDebounced]);

    const nextPage = () => {
        const newPage = page + 1;
        loadPage(newPage + 1);
        setPage(newPage);
    };

    const previousPage = () => {
        const newPage = page - 1;
        loadPage(newPage + 1);
        setPage(newPage);
    };

    const getVisibleTotalCount = useCallback((): number => {
        const teamsToAddCount = Object.keys(teamsToAdd).length;
        const teamsToRemoveCount = Object.keys(teamsToRemove).length;
        return totalCount + (teamsToAddCount - teamsToRemoveCount);
    }, [teamsToAdd, teamsToRemove, totalCount]);

    const getPaginationProps = useCallback((): {startCount: number; endCount: number; total: number} => {
        const startCount = (page * PAGE_SIZE) + 1;
        const total = getVisibleTotalCount();
        let endCount = (page + 1) * PAGE_SIZE;
        endCount = endCount > total ? total : endCount;

        return {startCount, endCount, total};
    }, [page, getVisibleTotalCount]);

    const removeTeam = (team: Team) => {
        if (teamsToRemove[team.id] === team) {
            return;
        }

        let newPage = page;
        const {endCount} = getPaginationProps();

        onRemoveCallback(team);
        if (endCount > getVisibleTotalCount() && (endCount % PAGE_SIZE) === 1 && newPage > 0) {
            newPage--;
        }

        setPage(newPage);
    };

    const getColumns = (): Column[] => {
        const name = (
            <FormattedMessage
                id='admin.team_settings.team_list.nameHeader'
                defaultMessage='Name'
            />
        );

        return [
            {
                name,
                field: 'name',
                fixed: true,
            },
            {
                name: '',
                field: 'remove',
                textAlign: 'right',
                fixed: true,
                className: 'TeamList__actionColumn',
            },
        ];
    };

    const getRows = () => {
        const {startCount, endCount} = getPaginationProps();
        let teamsToDisplay = teams;
        const includeTeamsList = Object.values(teamsToAdd);

        // Remove teams to remove and add teams to add
        teamsToDisplay = teamsToDisplay.filter((user) => !teamsToRemove[user.id]);
        teamsToDisplay = [...includeTeamsList, ...teamsToDisplay];
        teamsToDisplay = teamsToDisplay.slice(startCount - 1, endCount);

        if (teamsToDisplay.length < PAGE_SIZE && teams.length < totalCount) {
            const numberOfTeamsRemoved = Object.keys(teamsToRemove).length;
            const pagesOfTeamsRemoved = Math.floor(numberOfTeamsRemoved / PAGE_SIZE);
            const pageToLoad = page + pagesOfTeamsRemoved + 1;

            if (pageToLoad > pageLoaded.current) {
                loadPage(pageToLoad + 1);
                pageLoaded.current = pageToLoad;
            }
        }

        return teamsToDisplay.map((team) => {
            return {
                cells: {
                    id: team.id,
                    name: (
                        <div
                            className='TeamList__nameColumn'
                            id={`team-name-${team.id}`}
                        >
                            <div className='TeamList__lowerOpacity'>
                                <TeamIcon
                                    size='sm'
                                    url={Utils.imageURLForTeam(team)}
                                    content={team.display_name}
                                />
                            </div>
                            <div className='TeamList__nameText'>
                                <b data-testid='team-display-name'>
                                    {team.display_name}
                                </b>
                            </div>
                        </div>
                    ),
                    remove: (
                        <a
                            id={`remove-team-${team.id}`}
                            className='group-actions TeamList_editText'
                            onClick={(e) => {
                                e.preventDefault();
                                removeTeam(team);
                            }}
                            href='#'
                        >
                            <FormattedMessage
                                id='admin.data_retention.custom_policy.teams.remove'
                                defaultMessage='Remove'
                            />
                        </a>
                    ),
                },
            };
        });
    };

    const onSearch = async (term: string) => {
        actions.setTeamListSearch(term);
    };

    const rows: Row[] = getRows();
    const columns: Column[] = getColumns();
    const {startCount, endCount, total} = getPaginationProps();

    return (
        <div className='PolicyTeamsList'>
                <DataGrid
                    columns={columns}
                    rows={rows}
                    loading={loading}
                    nextPage={nextPage}
                    previousPage={previousPage}
                    startCount={startCount}
                    endCount={endCount}
                    total={total}
                    className={'customTable'}
                    onSearch={onSearch}
                    term={searchTerm}
                />
            </div>
    );
}