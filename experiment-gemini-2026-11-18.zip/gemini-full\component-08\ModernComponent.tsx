import debounce from 'lodash/debounce';
import isEqual from 'lodash/isEqual';
import React, {useCallback, useEffect, useMemo, useRef, useState} from 'react';
import {FormattedMessage, injectIntl} from 'react-intl';
import type {WrappedComponentProps} from 'react-intl';
import {Checkbox} from '@mattermost/compass-ui/components/checkbox';
import {WithTooltip} from '@mattermost/shared/components/tooltip';
import type {ChannelSearchOpts, ChannelWithTeamData} from '@mattermost/types/channels';
import type {ActionResult} from 'mattermost-redux/types/actions';
import DataGrid from 'components/admin_console/data_grid/data_grid';
import type {Column, Row} from 'components/admin_console/data_grid/data_grid';
import type {FilterOptions} from 'components/admin_console/filter/filter';
import TeamFilterDropdown from 'components/admin_console/filter/team_filter_dropdown';
import {ChannelIcon} from 'components/channel_type_icon';
import {Constants} from 'utils/constants';
import './channel_list.scss';

type PolicyActiveStatus = {
    id: string;
    active: boolean;
};

type Props = WrappedComponentProps & {
    channels: ChannelWithTeamData[];
    totalCount: number;
    searchTerm: string;
    filters: ChannelSearchOpts;
    policyId?: string;
    onRemoveCallback: (channel: ChannelWithTeamData) => void;
    channelsToRemove: Record<string, ChannelWithTeamData>;
    channelsToAdd: Record<string, ChannelWithTeamData>;
    policyActiveStatusChanges?: PolicyActiveStatus[];
    onPolicyActiveStatusChange?: (changes: PolicyActiveStatus[]) => void;
    saving?: boolean;
    hideTeamColumn?: boolean;
    actions: {
        searchChannels: (id: string, term: string, opts: ChannelSearchOpts) => Promise<ActionResult>;
        setChannelListSearch: (term: string) => void;
        setChannelListFilters: (filters: ChannelSearchOpts) => void;
    };
};

const PAGE_SIZE = 10;

const ChannelList: React.FC<Props> = ({
    channels,
    totalCount,
    searchTerm,
    filters,
    policyId,
    onRemoveCallback,
    channelsToRemove,
    channelsToAdd,
    policyActiveStatusChanges = [],
    onPolicyActiveStatusChange,
    saving,
    hideTeamColumn,
    actions,
    intl,
}) => {
    const [loading, setLoading] = useState(false);
    const [page, setPage] = useState(0);
    const [after, setAfter] = useState('');
    const [cursorHistory, setCursorHistory] = useState<string[]>([]);

    const isMounted = useRef(false);
    const isInitialMount = useRef(true);
    const prevFilters = useRef<ChannelSearchOpts>(filters);
    const prevSearchTerm = useRef<string>(searchTerm);

    const propsRef = useRef({policyId, searchTerm, filters, actions});
    propsRef.current = {policyId, searchTerm, filters, actions};

    const loadPage = useCallback(async (pageNumber: number, pageSize = PAGE_SIZE + 1) => {
        const {policyId: currentPolicyId, searchTerm: currentSearchTerm, filters: currentFilters, actions: currentActions} = propsRef.current;

        if (!currentPolicyId || !isMounted.current) {
            return;
        }

        setLoading(true);

        const searchFilters = {...currentFilters, page: pageNumber, per_page: pageSize};

        try {
            const action = await currentActions.searchChannels(currentPolicyId, currentSearchTerm, searchFilters);
            const data = action.data.channels || [];

            // Check if we have more data than the page size, indicating there's a next page
            const hasNextPage = data.length > PAGE_SIZE;

            // If we have more data than needed, remove the extra item (which is used to check for next page)
            const channelList = hasNextPage ? data.slice(0, PAGE_SIZE) : data;

            // Get the ID of the last channel for the next cursor
            const lastChannelId = channelList.length > 0 ? channelList[channelList.length - 1].id : '';

            if (isMounted.current) {
                setAfter(lastChannelId);
                setLoading(false);
            }
        } catch {
            if (isMounted.current) {
                setLoading(false);
            }
        }
    }, []);

    const searchDebounced = useMemo(
        () =>
            debounce(async () => {
                const {policyId: currentPolicyId, searchTerm: currentSearchTerm, filters: currentFilters, actions: currentActions} = propsRef.current;
                if (currentPolicyId) {
                    await currentActions.searchChannels(currentPolicyId, currentSearchTerm, currentFilters);
                }
                if (isMounted.current) {
                    setLoading(false);
                }
            }, Constants.SEARCH_TIMEOUT_MILLISECONDS),
        [],
    );

    useEffect(() => {
        isMounted.current = true;
        loadPage(0, PAGE_SIZE + 1);

        return () => {
            searchDebounced.cancel();
            isMounted.current = false;
        };
    }, [loadPage, searchDebounced]);

    useEffect(() => {
        if (isInitialMount.current) {
            isInitialMount.current = false;
            return;
        }

        const filtersModified = !isEqual(prevFilters.current, filters);
        const searchTermModified = prevSearchTerm.current !== searchTerm;

        prevFilters.current = filters;
        prevSearchTerm.current = searchTerm;

        if (searchTermModified || filtersModified) {
            setLoading(true);

            if (searchTerm === '') {
                const handleEmptySearch = async () => {
                    if (filtersModified && policyId) {
                        await actions.searchChannels(policyId, searchTerm, filters);
                    } else {
                        // Reset pagination state when clearing search
                        setAfter('');
                        setPage(0);
                        setCursorHistory([]);
                        await loadPage(0, PAGE_SIZE + 1);
                    }
                    if (isMounted.current) {
                        setLoading(false);
                    }
                };
                handleEmptySearch();
                return;
            }

            searchDebounced();
        }
    }, [searchTerm, filters, policyId, actions, loadPage, searchDebounced]);

    const nextPage = async () => {
        // Save current cursor to history for "previous" navigation
        const newCursorHistory = [...cursorHistory, after];

        setLoading(true);
        setPage((prevPage) => prevPage + 1);
        setCursorHistory(newCursorHistory);

        await loadPage(page + 1, PAGE_SIZE);
    };

    const previousPage = async () => {
        if (cursorHistory.length === 0) {
            return;
        }

        // Remove the current cursor from history
        const newCursorHistory = [...cursorHistory];
        newCursorHistory.pop();

        setLoading(true);
        setPage((prevPage) => prevPage - 1);
        setCursorHistory(newCursorHistory);

        await loadPage(page - 1, PAGE_SIZE);
    };

    const getVisibleTotalCount = (): number => {
        const channelsToAddCount = Object.keys(channelsToAdd).length;
        return totalCount + channelsToAddCount;
    };

    const getPaginationProps = (): {startCount: number; endCount: number; total: number} => {
        const startCount = (page * PAGE_SIZE) + 1;
        const total = getVisibleTotalCount();
        const endCount = Math.min((page + 1) * PAGE_SIZE, total);

        return {startCount, endCount, total};
    };

    const removeChannel = (channel: ChannelWithTeamData) => {
        // If the channel is not marked for removal, mark it
        onRemoveCallback(channel);

        const {endCount} = getPaginationProps();
        if (endCount > getVisibleTotalCount() && (endCount % PAGE_SIZE) === 1 && page > 0) {
            setPage((prevPage) => prevPage - 1);
        }
    };

    const handleAutoAddToggle = (channelId: string, currentStatus: boolean) => {
        if (!onPolicyActiveStatusChange || saving) {
            return;
        }

        const newStatus = !currentStatus;
        const existingChangeIndex = policyActiveStatusChanges.findIndex((change) => change.id === channelId);
        const updatedChanges = [...policyActiveStatusChanges];

        if (existingChangeIndex >= 0) {
            // Update existing change
            updatedChanges[existingChangeIndex] = {
                id: channelId,
                active: newStatus,
            };
        } else {
            // Add new change
            updatedChanges.push({
                id: channelId,
                active: newStatus,
            });
        }

        onPolicyActiveStatusChange(updatedChanges);
    };

    const getChannelAutoAddStatus = (channelId: string): boolean => {
        const change = policyActiveStatusChanges.find((c) => c.id === channelId);

        // If there's a pending change, use that status
        if (change) {
            return change.active;
        }

        const allChannels = [...channels, ...Object.values(channelsToAdd)];
        const channel = allChannels.find((ch) => ch.id === channelId);

        return channel?.policy_auto_add ?? false;
    };

    const getAllChannelsAutoAddStatus = (): {allActive: boolean; allInactive: boolean; mixed: boolean} => {
        const {startCount, endCount} = getPaginationProps();

        // Get all visible channels
        const channelsToDisplay = [
            ...Object.values(channelsToAdd),
            ...channels.filter((channel) => !channelsToRemove[channel.id]),
        ].slice(startCount - 1, endCount);

        if (channelsToDisplay.length === 0) {
            return {allActive: false, allInactive: false, mixed: false};
        }

        let activeCount = 0;
        channelsToDisplay.forEach((channel) => {
            if (getChannelAutoAddStatus(channel.id)) {
                activeCount++;
            }
        });

        const allActive = activeCount === channelsToDisplay.length;
        const allInactive = activeCount === 0;
        const mixed = !allActive && !allInactive;

        return {allActive, allInactive, mixed};
    };

    const handleBulkAutoAddToggle = () => {
        const {startCount, endCount} = getPaginationProps();

        if (!onPolicyActiveStatusChange || saving) {
            return;
        }

        // Get all visible channels
        const channelsToDisplay = [
            ...Object.values(channelsToAdd),
            ...channels.filter((channel) => !channelsToRemove[channel.id]),
        ].slice(startCount - 1, endCount);

        const {allActive} = getAllChannelsAutoAddStatus();
        const newStatus = !allActive; // If all are active, make them inactive; otherwise make them all active

        const updatedChanges = [...policyActiveStatusChanges];

        channelsToDisplay.forEach((channel) => {
            const existingChangeIndex = updatedChanges.findIndex((change) => change.id === channel.id);

            if (existingChangeIndex >= 0) {
                // Update existing change
                updatedChanges[existingChangeIndex] = {
                    id: channel.id,
                    active: newStatus,
                };
            } else {
                // Add new change
                updatedChanges.push({
                    id: channel.id,
                    active: newStatus,
                });
            }
        });

        onPolicyActiveStatusChange(updatedChanges);
    };

    const getColumns = (): Column[] => {
        const columns: Column[] = [
            {
                name: (
                    <FormattedMessage
                        id='admin.channel_settings.channel_list.nameHeader'
                        defaultMessage='Name'
                    />
                ),
                field: 'name',
                fixed: true,
                width: hideTeamColumn ? 10 : 7,
            },
        ];

        if (!hideTeamColumn) {
            columns.push({
                name: (
                    <FormattedMessage
                        id='admin.channel_settings.channel_list.teamHeader'
                        defaultMessage='Team'
                    />
                ),
                field: 'team',
                fixed: true,
                width: 7,
            });
        }

        const autoAddHeaderStatus = getAllChannelsAutoAddStatus();

        columns.push(
            {
                name: (
                    <div className='ChannelList__autoAddHeader'>
                        <Checkbox
                            id='auto-add-header-checkbox'
                            className='header-checkbox'
                            data-testid='auto-add-header-checkbox'
                            checked={autoAddHeaderStatus.allActive}
                            indeterminate={autoAddHeaderStatus.mixed}
                            disabled={saving}
                            onChange={handleBulkAutoAddToggle}
                        >
                            <FormattedMessage
                                id='admin.access_control.policy.channel_list.autoAddHeader'
                                defaultMessage='Auto-add members'
                            />
                        </Checkbox>
                        <WithTooltip
                            title={intl.formatMessage({
                                id: 'admin.access_control.policy.channel_list.autoAddTooltip.line1',
                                defaultMessage: 'Toggle to auto-add members who meet all access requirements',
                            })}
                            hint={intl.formatMessage({
                                id: 'admin.access_control.policy.channel_list.autoAddTooltip.line2',
                                defaultMessage: 'Channel administrators can modify this setting',
                            })}
                        >
                            <i className='icon icon-information-outline ChannelList__autoAddInfoIcon'/>
                        </WithTooltip>
                    </div>
                ),
                field: 'autoAdd',
                textAlign: 'left',
                fixed: true,
                width: hideTeamColumn ? 9 : 8,
            },
            {
                name: '',
                field: 'remove',
                textAlign: 'right',
                fixed: true,
                width: hideTeamColumn ? 3 : 3,
            },
        );

        return columns;
    };

    const getRows = () => {
        const {startCount, endCount} = getPaginationProps();

        // Combine channels to add with existing channels
        const channelsToDisplay = [
            ...Object.values(channelsToAdd),
            ...channels.filter((channel) => !channelsToRemove[channel.id]),
        ].slice(startCount - 1, endCount);

        return channelsToDisplay.map((channel) => {
            const iconToDisplay = (
                <ChannelIcon
                    channel={channel}
                    className='channel-icon'
                    data-testid={`${channel.name}-archive-icon`}
                />
            );

            // Determine the button text and action based on the channel state
            const buttonText = (
                <FormattedMessage
                    id='admin.access_control.policy.edit_policy.channel_selector.remove'
                    defaultMessage='Remove'
                />
            );

            const autoAddStatus = getChannelAutoAddStatus(channel.id);

            return {
                cells: {
                    id: channel.id,
                    name: (
                        <div
                            className='ChannelList__nameColumn'
                            id={`channel-name-${channel.id}`}
                        >
                            {iconToDisplay}
                            <div className='ChannelList__nameText'>
                                <b id={`display-name-channel-${channel.id}`}>
                                    {channel.display_name}
                                </b>
                            </div>
                        </div>
                    ),
                    team: channel.team_display_name,
                    autoAdd: (
                        <div className='ChannelList__autoAddColumn'>
                            <Checkbox
                                id={`auto-add-checkbox-${channel.id}`}
                                className='channel-checkbox'
                                data-testid={`auto-add-checkbox-${channel.id}`}
                                checked={autoAddStatus}
                                disabled={saving}
                                onChange={() => handleAutoAddToggle(channel.id, autoAddStatus)}
                            >
                                {autoAddStatus ? (
                                    <FormattedMessage
                                        id='admin.access_control.policy.channel_list.on'
                                        defaultMessage='On'
                                    />
                                ) : (
                                    <FormattedMessage
                                        id='admin.access_control.policy.channel_list.off'
                                        defaultMessage='Off'
                                    />
                                )}
                            </Checkbox>
                        </div>
                    ),
                    remove: (
                        <a
                            id={`remove-channel-${channel.id}`}
                            className={'group-actions TeamList_editText'}
                            onClick={(e) => {
                                e.preventDefault();
                                removeChannel(channel);
                            }}
                            href='#'
                        >
                            {buttonText}
                        </a>
                    ),
                },
            };
        });
    };

    const onSearch = (term: string) => {
        actions.setChannelListSearch(term);
    };

    const onFilter = (filterOptions: FilterOptions) => {
        const newFilters: ChannelSearchOpts = {};
        const {team_ids: teamIds} = filterOptions.teams.values;
        if ((teamIds.value as string[]).length) {
            newFilters.team_ids = teamIds.value as string[];
        }
        actions.setChannelListFilters(newFilters);
    };

    const rows: Row[] = getRows();
    const columns: Column[] = getColumns();
    const {startCount, endCount, total} = getPaginationProps();

    const filterOptions: FilterOptions = {
        teams: {
            name: 'Teams',
            values: {
                team_ids: {
                    name: (
                        <FormattedMessage
                            id='admin.team_settings.title'
                            defaultMessage='Teams'
                        />
                    ),
                    value: [],
                },
            },
            keys: ['team_ids'],
            type: TeamFilterDropdown,
        },
    };

    const filterProps = hideTeamColumn ? undefined : {
        options: filterOptions,
        keys: ['teams'],
        onFilter,
    };

    return (
        <div className='AccessControlPolicyChannelsList'>
                <DataGrid
                    columns={columns}
                    rows={rows}
                    loading={loading}
                    nextPage={nextPage}
                    previousPage={previousPage}
                    startCount={startCount}
                    endCount={endCount}
                    total={total}
                    className={'customTable'}
                    onSearch={onSearch}
                    term={searchTerm}
                    filterProps={filterProps}
                />
            </div>
    );
};

export default injectIntl(ChannelList);