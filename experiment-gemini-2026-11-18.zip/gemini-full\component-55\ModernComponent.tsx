import React, {type JSX, useCallback, useEffect, useRef, useState} from 'react';
import {createPortal} from 'react-dom';
import type {IntlShape} from 'react-intl';
import {injectIntl} from 'react-intl';
import type {AppBinding} from '@mattermost/types/apps';
import type {Post} from '@mattermost/types/posts';
import {AppCallResponseTypes} from 'mattermost-redux/constants/apps';
import type {ActionResult} from 'mattermost-redux/types/actions';
import MarketplaceModal from 'components/plugin_marketplace/marketplace_modal';
import Menu from 'components/widgets/menu/menu';
import MenuWrapper from 'components/widgets/menu/menu_wrapper';
import Pluggable from 'plugins/pluggable';
import {createCallContext} from 'utils/apps';
import {Constants, Locations, ModalIdentifiers} from 'utils/constants';
import * as PostUtils from 'utils/post_utils';
import type {ModalData} from 'types/actions';
import type {HandleBindingClick, OpenAppsModal, PostEphemeralCallResponseForPost} from 'types/apps';
import type {PostDropdownMenuAction, PostDropdownMenuItemComponent} from 'types/store/plugins';
import ActionsMenuButton from './actions_menu_button';
import ActionsMenuEmptyPopover from './actions_menu_empty_popover';
import {ActionsMenuIcon} from './actions_menu_icon';
import './actions_menu.scss';

const MENU_BOTTOM_MARGIN = 80;

export const PLUGGABLE_COMPONENT = 'PostDropdownMenuItem';

export type Props = {
    appBindings: AppBinding[] | null;
    appsEnabled: boolean;
    handleDropdownOpened: (open: boolean) => void;
    intl: IntlShape;
    isMenuOpen: boolean;
    isMobileView: boolean;
    isSysAdmin: boolean;
    location?: 'CENTER' | 'RHS_ROOT' | 'RHS_COMMENT' | 'SEARCH' | string;
    pluginMenuItems?: PostDropdownMenuAction[];
    post: Post;
    teamId: string;
    canOpenMarketplace: boolean;

    /**
     * Components for overriding provided by plugins
     */
    pluginMenuItemComponents: PostDropdownMenuItemComponent[];

    actions: {

        /**
         * Function to open a modal
         */
        openModal: <P>(modalData: ModalData<P>) => void;

        /**
         * Function to post the ephemeral message for a call response
         */
        postEphemeralCallResponseForPost: PostEphemeralCallResponseForPost;

        /**
         * Function to handle clicking of any post-menu bindings
         */
        handleBindingClick: HandleBindingClick;

        /**
         * Function to open the Apps modal with a form
         */
        openAppsModal: OpenAppsModal;

        /**
         * Function to get the post menu bindings for this post.
         */
        fetchBindings: (channelId: string, teamId: string) => Promise<ActionResult<AppBinding[]>>;

    }; // TechDebt: Made non-mandatory while converting to typescript
};

export const ActionMenuClass: React.FC<Props> = (props) => {
    const {
        appBindings: appBindingsProp = [],
        appsEnabled,
        handleDropdownOpened: onDropdownOpened,
        intl,
        isMenuOpen,
        isMobileView,
        isSysAdmin,
        location = Locations.CENTER,
        pluginMenuItems = [],
        post,
        teamId,
        canOpenMarketplace,
        pluginMenuItemComponents,
        actions,
    } = props;

    const [openUp, setOpenUp] = useState(false);
    const [stateAppBindings, setStateAppBindings] = useState<AppBinding[] | undefined>(
        appBindingsProp ?? undefined,
    );
    const [buttonElement, setButtonElement] = useState<HTMLButtonElement | null>(null);

    const menuPortalRef = useRef<HTMLDivElement>(null);
    const prevIsMenuOpenRef = useRef(isMenuOpen);

    useEffect(() => {
        if (props.appBindings) {
            setStateAppBindings(props.appBindings);
        }
    }, [props.appBindings]);

    useEffect(() => {
        if (isMenuOpen && !prevIsMenuOpenRef.current) {
            if (appsEnabled && !stateAppBindings) {
                actions.fetchBindings(post.channel_id, teamId).then(({data}) => {
                    setStateAppBindings(data);
                });
            }
        }
        prevIsMenuOpenRef.current = isMenuOpen;
    }, [isMenuOpen, appsEnabled, stateAppBindings, actions, post.channel_id, teamId]);

    const buttonRef = useCallback((element: HTMLButtonElement | null) => {
        setButtonElement(element);
    }, []);

    const openDropdown = () => {
        onDropdownOpened(true);
    };

    const closeDropdown = () => {
        onDropdownOpened(false);
    };

    const handleDropdownOpened = (open: boolean) => {
        onDropdownOpened(open);

        if (!open) {
            return;
        }

        const buttonRect = buttonElement?.getBoundingClientRect();
        let y;
        if (typeof buttonRect?.y === 'undefined') {
            y = typeof buttonRect?.top === 'undefined' ? 0 : buttonRect?.top;
        } else {
            y = buttonRect?.y;
        }
        const windowHeight = window.innerHeight;

        const totalSpace = windowHeight - MENU_BOTTOM_MARGIN;
        const spaceOnTop = y - Constants.CHANNEL_HEADER_HEIGHT;
        const spaceOnBottom = (totalSpace - (spaceOnTop + Constants.POST_AREA_HEIGHT));

        setOpenUp(spaceOnTop > spaceOnBottom);
    };

    const handleOpenMarketplace = (): void => {
        closeDropdown();

        // Wait for the menu to close to avoid clashing between the menu's focus trap and the modal's
        requestAnimationFrame(() => {
            const openMarketplaceData = {
                modalId: ModalIdentifiers.PLUGIN_MARKETPLACE,
                dialogType: MarketplaceModal,
            };
            actions.openModal(openMarketplaceData);
        });
    };

    const onClickAppBinding = async (binding: AppBinding) => {
        const context = createCallContext(
            binding.app_id,
            binding.location,
            post.channel_id,
            teamId,
            post.id,
            post.root_id,
        );

        const res = await actions.handleBindingClick(binding, context, intl);

        if (res.error) {
            const errorResponse = res.error;
            const errorMessage = errorResponse.text || intl.formatMessage({
                id: 'apps.error.unknown',
                defaultMessage: 'Unknown error occurred.',
            });
            actions.postEphemeralCallResponseForPost(errorResponse, errorMessage, post);
            return;
        }

        const callResp = res.data!;
        switch (callResp.type) {
        case AppCallResponseTypes.OK:
            if (callResp.text) {
                actions.postEphemeralCallResponseForPost(callResp, callResp.text, post);
            }
            break;
        case AppCallResponseTypes.NAVIGATE:
            break;
        case AppCallResponseTypes.FORM:
            if (callResp.form) {
                actions.openAppsModal(callResp.form, context);
            }
            break;
        default: {
            const errorMessage = intl.formatMessage({
                id: 'apps.error.responses.unknown_type',
                defaultMessage: 'App response type not supported. Response type: {type}.',
            }, {
                type: callResp.type,
            });
            actions.postEphemeralCallResponseForPost(callResp, errorMessage, post);
        }
        }
    };

    const renderDivider = (suffix: string): React.ReactNode => {
        return (
            <li
                id={`divider_post_${post.id}_${suffix}`}
                className='MenuItem__divider'
                role='menuitem'
            />
        );
    };

    const isSystemMessage = PostUtils.isSystemMessage(post);
    if (isSystemMessage) {
        return null;
    }

    const pluginItems = pluginMenuItems?.
        filter((item) => {
            return item.filter ? item.filter(post.id) : item;
        }).
        map((item) => {
            if (item.subMenu) {
                return (
                    <Menu.ItemSubMenu
                            key={item.id + '_pluginmenuitem'}
                            id={item.id}
                            postId={post.id}
                            text={item.text}
                            subMenu={item.subMenu}
                            action={item.action}
                            root={true}
                        />
                );
            }
            return (
                <Menu.ItemAction
                        key={item.id + '_pluginmenuitem'}
                        text={item.text}
                        onClick={() => {
                            if (item.action) {
                                item.action(post.id);
                            }
                        }}
                    />
            );
        });

    let appBindings = [] as JSX.Element[];
    if (appsEnabled && stateAppBindings) {
        appBindings = stateAppBindings.map((item) => {
            let icon: JSX.Element | undefined;
            if (item.icon) {
                icon = (
                    <img
                        key={item.app_id + 'app_icon'}
                        src={item.icon}
                    />);
            }

            return (
                <Menu.ItemAction
                        text={item.label}
                        key={item.app_id + item.location}
                        onClick={() => onClickAppBinding(item)}
                        icon={icon}
                    />
            );
        });
    }

    const {formatMessage} = intl;

    let marketPlace = null;
    if (canOpenMarketplace) {
        marketPlace = (
            <React.Fragment key={'marketplace'}>
                {renderDivider('marketplace')}
                <Menu.ItemAction
                    id={`marketplace_icon_${post.id}`}
                    key={`marketplace_${post.id}`}
                    show={true}
                    text={formatMessage({id: 'post_info.marketplace', defaultMessage: 'App Marketplace'})}
                    icon={<ActionsMenuIcon name='icon-view-grid-plus-outline'/>}
                    onClick={handleOpenMarketplace}
                />
            </React.Fragment>
        );
    }

    const hasApps = Boolean(appBindings.length);
    const hasPluggables = Boolean(pluginMenuItemComponents?.length);
    const hasPluginItems = Boolean(pluginItems?.length);

    const hasPluginMenuItems = hasPluginItems || hasApps || hasPluggables;
    if (!canOpenMarketplace && !hasPluginMenuItems) {
        return null;
    }

    const buttonId = `${location}_actions_button_${post.id}`;
    const popupId = `${location}_actions_dropdown_${post.id}`;

    if (hasPluginMenuItems) {
        const pluggable = (
            <Pluggable
                postId={post.id}
                pluggableName={PLUGGABLE_COMPONENT}
                key={post.id + 'pluggable'}
            />
        );

        const menuItems = [
            pluginItems,
            appBindings,
            pluggable,
            marketPlace,
        ];

        const menu = (
            <Menu
                listId={popupId}
                openLeft={true}
                openUp={openUp}
                ariaLabel={formatMessage({id: 'post_info.menuAriaLabel', defaultMessage: 'Post extra options'})}
            >
                {menuItems}
            </Menu>
        );

        // In mobile view the menu renders as a full-screen fixed overlay. Posts live inside the
        // virtualized post list, whose `will-change: transform` makes it the containing block for
        // fixed descendants, so the overlay would anchor to the scrolled content instead of the
        // viewport. Portaling to the body escapes that containing block, and we hand the portal
        // node to MenuWrapper so its blur handling still treats the menu as inside itself.
        return (
            <MenuWrapper
                    open={isMenuOpen}
                    onToggle={handleDropdownOpened}
                    portalNodeRef={menuPortalRef}
                >
                    <ActionsMenuButton
                        ref={buttonRef}
                        buttonId={buttonId}
                        popupId={popupId}
                        isMenuOpen={isMenuOpen}
                    />
                    {isMobileView ? createPortal(
                        <div
                            className='post-actions-menu-mobile'
                            ref={menuPortalRef}
                        >
                            {menu}
                        </div>,
                        document.body,
                    ) : menu}
                </MenuWrapper>
        );
    } else if (isSysAdmin) {
        return (
            <>

                    <ActionsMenuButton
                        ref={buttonRef}
                        buttonId={buttonId}
                        onClick={openDropdown}
                        popupId={popupId}
                        isMenuOpen={isMenuOpen}
                    />
                    <ActionsMenuEmptyPopover
                        anchorElement={buttonElement}
                        onOpenMarketplace={handleOpenMarketplace}
                        onToggle={handleDropdownOpened}
                        isOpen={isMenuOpen}
                    />
                </>
        );
    }

    return null;
};

export default injectIntl(ActionMenuClass);