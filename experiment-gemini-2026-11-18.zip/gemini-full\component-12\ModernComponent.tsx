import classNames from 'classnames';
import React, {useCallback, useEffect, useRef, useState} from 'react';
import type {CSSProperties, JSX} from 'react';
import {FormattedMessage, injectIntl} from 'react-intl';
import type {WrappedComponentProps} from 'react-intl';
import type {FilterOptions} from 'components/admin_console/filter/filter';
import NextIcon from 'components/widgets/icons/fa_next_icon';
import PreviousIcon from 'components/widgets/icons/fa_previous_icon';
import LoadingSpinner from 'components/widgets/loading/loading_spinner';
import DataGridHeader from './data_grid_header';
import DataGridRow from './data_grid_row';
import DataGridSearch from './data_grid_search';
import './data_grid.scss';

export type Column = {
    name: string | JSX.Element;
    field: string;
    fixed?: boolean;

    // Optional styling overrides
    className?: string;
    width?: number;
    textAlign?: '-moz-initial' | 'inherit' | 'initial' | 'revert' | 'unset' | 'center' | 'end' | 'justify' | 'left' | 'match-parent' | 'right' | 'start' | undefined;
    overflow?: string;
};

export type Row = {
    cells: {
        [key: string]: JSX.Element | string | null;
    };
    onClick?: () => void;
};

type Props = {
    rows: Row[];
    columns: Column[];
    placeholderEmpty?: JSX.Element;
    loadingIndicator?: JSX.Element;

    rowsContainerStyles?: CSSProperties;

    minimumColumnWidth?: number;

    startCount: number;
    endCount: number;
    total?: number;
    loading: boolean;

    nextPage: () => void;
    previousPage: () => void;

    onSearch?: (term: string) => void;
    term?: string;
    extraComponent?: JSX.Element;
    filterProps?: {
        options: FilterOptions;
        keys: string[];
        onFilter: (options: FilterOptions) => void;
    };

    className?: string;
    disabled?: boolean;
} & WrappedComponentProps;

const MINIMUM_COLUMN_WIDTH = 100;

const DataGrid: React.FC<Props> = ({
    rows,
    columns,
    placeholderEmpty,
    loadingIndicator,
    rowsContainerStyles,
    minimumColumnWidth = MINIMUM_COLUMN_WIDTH,
    startCount,
    endCount,
    total,
    loading,
    nextPage,
    previousPage,
    onSearch,
    term = '',
    extraComponent,
    filterProps,
    className,
    disabled,
    intl,
}) => {
    const ref = useRef<HTMLDivElement>(null);
    const [visibleColumns, setVisibleColumns] = useState<Column[]>(columns);

    const handleResize = useCallback(() => {
        if (!ref.current) {
            return;
        }

        const fixedColumns = columns.filter((col) => col.fixed);
        const fixedColumnWidth = fixedColumns.length * minimumColumnWidth;

        let newVisibleColumns: Column[] = columns;
        let availableWidth = ref.current.clientWidth - fixedColumnWidth - 50;

        newVisibleColumns = newVisibleColumns.filter((column) => {
            if (availableWidth > minimumColumnWidth) {
                availableWidth -= minimumColumnWidth;
                return true;
            }

            return Boolean(column.fixed);
        });

        setVisibleColumns(newVisibleColumns);
    }, [columns, minimumColumnWidth]);

    useEffect(() => {
        setVisibleColumns(columns);
    }, [columns]);

    useEffect(() => {
        handleResize();
        window.addEventListener('resize', handleResize);
        return () => {
            window.removeEventListener('resize', handleResize);
        };
    }, [handleResize]);

    const handleNextPage = () => {
        if (!loading) {
            nextPage();
        }
    };

    const handlePreviousPage = () => {
        if (!loading) {
            previousPage();
        }
    };

    const search = (searchTerm: string) => {
        if (onSearch) {
            onSearch(searchTerm);
        }
    };

    const renderRows = (): JSX.Element => {
        let rowsToRender: JSX.Element | JSX.Element[] | null = null;

        if (loading) {
            if (loadingIndicator) {
                rowsToRender = (
                    <div className='DataGrid_loading'>
                        {loadingIndicator}
                    </div>
                );
            } else {
                rowsToRender = (
                    <div className='DataGrid_loading'>
                        <LoadingSpinner/>
                        <FormattedMessage
                            id='admin.data_grid.loading'
                            defaultMessage='Loading'
                        />
                    </div>
                );
            }
        } else if (rows.length === 0) {
            const placeholder = placeholderEmpty || (
                <FormattedMessage
                    id='admin.data_grid.empty'
                    defaultMessage='No items found'
                />
            );
            rowsToRender = (
                <div className='DataGrid_empty'>
                    {placeholder}
                </div>
            );
        } else {
            rowsToRender = rows.map((row, index) => {
                return (
                    <DataGridRow
                        key={index}
                        row={row}
                        columns={visibleColumns}
                    />
                );
            });
        }
        return (
            <div
                className='DataGrid_rows'
                data-testid='dataGrid-rows'
                style={rowsContainerStyles || {}}
            >
                {rowsToRender}
            </div>
        );
    };

    const renderHeader = (): JSX.Element => {
        return (
            <DataGridHeader
                columns={visibleColumns}
            />
        );
    };

    const renderSearch = (): JSX.Element | null => {
        if (onSearch) {
            return (
                <DataGridSearch
                    onSearch={search}
                    term={term}
                    filterProps={filterProps}
                    extraComponent={extraComponent}
                    disabled={disabled}
                />
            );
        }
        return null;
    };

    const renderFooter = (): JSX.Element | null => {
        let footer: JSX.Element | null = null;

        if (total) {
            const firstPage = startCount <= 1;
            const lastPage = endCount >= total;

            let prevPageFn: () => void = handlePreviousPage;
            if (firstPage) {
                prevPageFn = () => {};
            }

            let nextPageFn: () => void = handleNextPage;
            if (lastPage) {
                nextPageFn = () => {};
            }

            footer = (
                <div
                    className='DataGrid_footer'
                    data-testid='dataGrid-footer'
                >
                    <div className='DataGrid_cell'>
                        <span data-testid='dataGrid-footer-paginationInfo'>
                            <FormattedMessage
                                id='admin.data_grid.paginatorCount'
                                defaultMessage='{startCount, number} - {endCount, number} of {total, number}'
                                values={{
                                    startCount,
                                    endCount,
                                    total,
                                }}
                            />
                        </span>
                        <button
                            aria-label={intl.formatMessage({id: 'admin.accessibility.previous_page', defaultMessage: 'Previous page'})}
                            type='button'
                            className={'btn btn-quaternary btn-icon btn-sm ml-2 prev ' + (firstPage ? 'disabled' : '')}
                            onClick={prevPageFn}
                            disabled={firstPage}
                        >
                            <PreviousIcon/>
                        </button>
                        <button
                            aria-label={intl.formatMessage({id: 'admin.accessibility.next_page', defaultMessage: 'Next page'})}
                            type='button'
                            className={'btn btn-quaternary btn-icon btn-sm next ' + (lastPage ? 'disabled' : '')}
                            onClick={nextPageFn}
                            disabled={lastPage}
                        >
                            <NextIcon/>
                        </button>
                    </div>
                </div>
            );
        }

        return footer;
    };

    return (
        <div
                className={classNames('DataGrid', className)}
                data-testid='dataGrid'
                ref={ref}
            >
                {renderSearch()}
                {renderHeader()}
                {renderRows()}
                {renderFooter()}
            </div>
    );
};

export default injectIntl(DataGrid);