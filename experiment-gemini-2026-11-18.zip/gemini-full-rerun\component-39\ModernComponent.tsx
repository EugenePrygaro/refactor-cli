import cx from "classnames";
import type { CSSProperties, ComponentType, ReactNode } from "react";
import { useCallback, useEffect, useRef, useState } from "react";
import { t } from "ttag";
import _ from "underscore";
import {
  cardApi,
  databaseApi,
  useLazyListDatabaseSchemaTablesQuery,
  useLazyListDatabaseSchemasQuery,
  useListDatabasesQuery,
  useSearchQuery,
} from "metabase/api";
import { runRtkEndpoint } from "metabase/api/utils/run-rtk-endpoint";
import { EmptyState } from "metabase/common/components/EmptyState";
import { LoadingAndErrorWrapper } from "metabase/common/components/LoadingAndErrorWrapper";
import CS from "metabase/css/core/index.css";
import { canUserCreateQueries } from "metabase/current-user";
import { getShallowQuestions } from "metabase/metadata-store";
import { connect } from "metabase/redux";
import type { Dispatch, State } from "metabase/redux/store";
import { fetchTableMetadata } from "metabase/redux/tables";
import { getSetting } from "metabase/settings";
import { Box, Popover } from "metabase/ui";
import {
  SAVED_QUESTIONS_VIRTUAL_DB_ID,
  getQuestionIdFromVirtualTableId,
  isVirtualCardId,
} from "metabase-lib/v1/metadata/utils/saved-questions";
import { parseSchemaId } from "metabase-lib/v1/metadata/utils/schema";
import type {
  CardType,
  CollectionId,
  DatabaseId,
  FieldId,
  FieldReference,
  ListDatabasesRequest,
  SchemaId,
  SearchModel,
  SearchResponse,
  TableId,
} from "metabase-types/api";
import { DataSelectorDataBucketPicker } from "./DataSelectorDataBucketPicker";
import { DataSelectorDatabasePicker } from "./DataSelectorDatabasePicker";
import { DataSelectorDatabaseSchemaPicker } from "./DataSelectorDatabaseSchemaPicker";
import { DataSelectorFieldPicker } from "./DataSelectorFieldPicker";
import { DataSelectorSchemaPicker } from "./DataSelectorSchemaPicker";
import { DataSelectorTablePicker } from "./DataSelectorTablePicker";
import {
  DatabaseTrigger,
  FieldTrigger,
  TableTrigger,
  Trigger,
  type TriggerComponentProps,
} from "./TriggerComponents";
import { CONTAINER_WIDTH, DATA_BUCKET } from "./constants";
import { type EntityLookups, getEntityLookups } from "./entity-lookups";
import { SavedEntityPicker } from "./saved-entity-picker/SavedEntityPicker";
import type {
  DataPickerDataType,
  DataSelectorDatabase,
  DataSelectorField,
  DataSelectorSchema,
  DataSelectorTable,
} from "./types";
import { getDataTypes } from "./utils";

const DATA_BUCKET_STEP = "BUCKET";

const DATABASE_STEP = "DATABASE";

const SCHEMA_STEP = "SCHEMA";

const TABLE_STEP = "TABLE";

const FIELD_STEP = "FIELD";

type DataSelectorStep =
  | typeof DATA_BUCKET_STEP
  | typeof DATABASE_STEP
  | typeof SCHEMA_STEP
  | typeof TABLE_STEP
  | typeof FIELD_STEP;

type AvailableModelsResult = Omit<SearchResponse, "data">;

export interface DataSelectorOwnProps {
  steps: DataSelectorStep[];
  combineDatabaseSchemaSteps?: boolean;
  getTriggerElementContent?: ComponentType<TriggerComponentProps>;
  triggerElement?: ReactNode;
  triggerIconSize?: number;
  triggerClasses?: string;
  containerClassName?: string;
  className?: string;
  style?: CSSProperties;
  isMantine?: boolean;
  isPopover?: boolean;
  isInitiallyOpen?: boolean;
  isOpen?: boolean;
  readOnly?: boolean;
  onClose?: () => void;
  hasTriggerExpandControl?: boolean;

  selectedDataBucketId?: DataPickerDataType | null;
  selectedDatabaseId?: DatabaseId | null;
  selectedSchemaId?: SchemaId | null;
  selectedTableId?: TableId | null;
  selectedFieldId?: FieldId | FieldReference | null;
  selectedCollectionId?: CollectionId;

  databaseQuery?: ListDatabasesRequest;
  databases?: DataSelectorDatabase[];
  schemas?: DataSelectorSchema[];
  tables?: DataSelectorTable[];
  fields?: DataSelectorField[];

  setDatabaseFn?: (databaseId: DatabaseId) => void;
  setFieldFn?: (fieldId: FieldId) => void;
  setSourceTableFn?: (tableId: TableId, databaseId?: DatabaseId) => void;
  tableFilter?: (table: DataSelectorTable) => boolean;
  fieldFilter?: (field: DataSelectorField) => boolean;
  databaseIsDisabled?: (database: DataSelectorDatabase) => boolean;
  databaseDisabledTooltip?: (
    database: DataSelectorDatabase,
  ) => string | undefined;

  canChangeDatabase?: boolean;
  canSelectModel?: boolean;
  canSelectTable?: boolean;
  canSelectMetric?: boolean;
  canSelectSavedQuestion?: boolean;
  useOnlyAvailableDatabase?: boolean;
  useOnlyAvailableSchema?: boolean;
}

interface DataSelectorStateProps {
  availableModels: SearchModel[];
  entityLookups: EntityLookups;
  databases: DataSelectorDatabase[];
  hasLoadedDatabasesWithTablesSaved: boolean;
  hasLoadedDatabasesWithSaved: boolean;
  hasLoadedDatabasesWithTables: boolean;
  hasDataAccess: boolean;
  hasNestedQueriesEnabled: boolean;
  selectedCardType?: CardType;
}

interface DataSelectorDispatchProps {
  fetchDatabases: (databaseQuery?: ListDatabasesRequest) => Promise<unknown>;
  fetchFields: (tableId: TableId) => Promise<unknown>;
  fetchQuestion: (id: TableId) => Promise<unknown>;
}

interface SchemaFetchersProps {
  fetchSchemas: (databaseId: DatabaseId) => Promise<unknown>;
  fetchSchemaTables: (schemaId: SchemaId) => Promise<unknown>;
}

interface AvailableModelsInjectedProps {
  loading: boolean;
  loaded: boolean;
  allLoading: boolean;
}

type DataSelectorProps = DataSelectorOwnProps &
  DataSelectorStateProps &
  DataSelectorDispatchProps &
  SchemaFetchersProps &
  AvailableModelsInjectedProps;

interface ComputedDataSelectorState {
  databases: DataSelectorDatabase[];
  selectedDatabase: DataSelectorDatabase | null;
  schemas: DataSelectorSchema[];
  selectedSchema: DataSelectorSchema | null;
  tables: DataSelectorTable[];
  selectedTable: DataSelectorTable | null;
  fields: DataSelectorField[];
  selectedField: DataSelectorField | null;
}

interface DataSelectorState extends ComputedDataSelectorState {
  activeStep: DataSelectorStep | null;
  isLoading: boolean;
  isError: boolean;
  isPopoverOpen: boolean;
  isSavedEntityPickerShown: boolean;
  savedEntityType: CardType | null;
  selectedDataBucketId: DataPickerDataType | null;
  selectedDatabaseId: DatabaseId | null;
  selectedSchemaId: SchemaId | null;
  selectedTableId: TableId | null;
  selectedFieldId: FieldId | FieldReference | null;
}

type SelectedIdsState = Pick<
  DataSelectorState,
  | "selectedDatabaseId"
  | "selectedSchemaId"
  | "selectedTableId"
  | "selectedFieldId"
>;

export function DataSourceSelector(props: Omit<DataSelectorOwnProps, "steps">) {
  return (
    <DataSelector
      steps={[DATA_BUCKET_STEP, DATABASE_STEP, SCHEMA_STEP, TABLE_STEP]}
      combineDatabaseSchemaSteps
      getTriggerElementContent={TableTrigger}
      {...props}
    />
  );
}

export function DatabaseDataSelector(
  props: Omit<DataSelectorOwnProps, "steps">,
) {
  return (
    <DataSelector
      steps={[DATABASE_STEP]}
      getTriggerElementContent={DatabaseTrigger}
      {...props}
    />
  );
}

export function DatabaseSchemaAndTableDataSelector(
  props: Omit<DataSelectorOwnProps, "steps">,
) {
  return (
    <DataSelector
      steps={[DATABASE_STEP, SCHEMA_STEP, TABLE_STEP]}
      combineDatabaseSchemaSteps
      getTriggerElementContent={TableTrigger}
      {...props}
    />
  );
}

export function SchemaAndTableDataSelector(
  props: Omit<DataSelectorOwnProps, "steps">,
) {
  return (
    <DataSelector
      steps={[SCHEMA_STEP, TABLE_STEP]}
      getTriggerElementContent={TableTrigger}
      {...props}
    />
  );
}

export function SchemaTableAndFieldDataSelector(
  props: Omit<DataSelectorOwnProps, "steps">,
) {
  return (
    <DataSelector
      steps={[SCHEMA_STEP, TABLE_STEP, FIELD_STEP]}
      getTriggerElementContent={FieldTrigger}
      // We don't want to change styles when there's a different trigger element
      isMantine={!props.getTriggerElementContent}
      {...props}
    />
  );
}

export function FieldDataSelector(props: Omit<DataSelectorOwnProps, "steps">) {
  return (
    <DataSelector
      steps={[FIELD_STEP]}
      getTriggerElementContent={FieldTrigger}
      {...props}
    />
  );
}

function getComputedState(
  props: DataSelectorProps,
  state: SelectedIdsState,
): ComputedDataSelectorState {
  const { entityLookups, tableFilter, fieldFilter } = props;
  const {
    selectedDatabaseId,
    selectedSchemaId,
    selectedTableId,
    selectedFieldId,
  } = state;

  let { databases, schemas, tables, fields } = props;
  let selectedDatabase: DataSelectorDatabase | null = null;
  let selectedSchema: DataSelectorSchema | null = null;
  let selectedTable: DataSelectorTable | null = null;
  let selectedField: DataSelectorField | null = null;

  const getDatabase = (id: DatabaseId) =>
    _.findWhere(databases, { id }) || entityLookups.database(id);
  const getSchema = (id: SchemaId) =>
    _.findWhere(schemas ?? [], { id }) || entityLookups.schema(id);
  const getTable = (id: TableId) =>
    _.findWhere(tables ?? [], { id }) || entityLookups.table(id);
  const getField = (id: FieldId | FieldReference) =>
    _.findWhere(fields ?? [], { id }) || entityLookups.field(id);

  const deriveFromDatabase = (database: DataSelectorDatabase | null) => {
    if (!schemas && database) {
      schemas = entityLookups.databaseSchemas(database.id);
    }
    if (!tables && Array.isArray(schemas) && schemas.length === 1) {
      tables = entityLookups.schemaTables(schemas[0].id);
    }
  };

  const deriveFromSchema = (schema: DataSelectorSchema | null) => {
    if (!tables && schema) {
      tables = entityLookups.schemaTables(schema.id);
    }
  };

  const deriveFromTable = (table: DataSelectorTable | null) => {
    if (!fields && table) {
      fields = entityLookups.tableFields(table.id);
    }
  };

  if (selectedDatabaseId != null) {
    selectedDatabase = getDatabase(selectedDatabaseId) ?? null;
    deriveFromDatabase(selectedDatabase);
  }
  if (selectedSchemaId != null && selectedDatabaseId) {
    selectedSchema = getSchema(selectedSchemaId) ?? null;
    deriveFromSchema(selectedSchema);
  }
  if (selectedTableId != null) {
    selectedTable = getTable(selectedTableId) ?? null;
    deriveFromTable(selectedTable);
  }
  if (selectedFieldId != null) {
    selectedField = getField(selectedFieldId) ?? null;
  }
  // now do it in in reverse to propagate it back up
  if (!selectedTable && selectedField) {
    selectedTable = entityLookups.table(selectedField.table_id) ?? null;
    deriveFromTable(selectedTable);
  }
  if (!selectedSchema && selectedTable) {
    selectedSchema = entityLookups.tableSchema(selectedTable.id) ?? null;
    deriveFromSchema(selectedSchema);
  }
  if (!selectedDatabase && selectedSchema) {
    selectedDatabase =
      entityLookups.database(selectedSchema.database) ?? null;
    deriveFromDatabase(selectedDatabase);
  }

  if (tables && tableFilter) {
    tables = tables.filter(tableFilter);
  }

  if (fields && fieldFilter) {
    fields = fields.filter(fieldFilter);
  }

  return {
    databases: databases || [],
    selectedDatabase: selectedDatabase ?? null,
    schemas: schemas || [],
    selectedSchema: selectedSchema ?? null,
    tables: tables || [],
    selectedTable: selectedTable ?? null,
    fields: fields || [],
    selectedField: selectedField ?? null,
  };
}

export function UnconnectedDataSelector(props: DataSelectorProps) {
  const {
    steps,
    combineDatabaseSchemaSteps,
    getTriggerElementContent,
    triggerElement: triggerElementProp,
    triggerIconSize,
    triggerClasses,
    containerClassName,
    className,
    style,
    isMantine = false,
    isPopover = true,
    isInitiallyOpen = false,
    isOpen,
    readOnly = false,
    onClose,
    hasTriggerExpandControl = true,
    selectedDataBucketId: propSelectedDataBucketId,
    selectedDatabaseId: propSelectedDatabaseId,
    selectedSchemaId: propSelectedSchemaId,
    selectedTableId: propSelectedTableId,
    selectedFieldId: propSelectedFieldId,
    selectedCollectionId,
    databaseQuery,
    setDatabaseFn,
    setFieldFn,
    setSourceTableFn,
    tableFilter,
    fieldFilter,
    databaseIsDisabled,
    databaseDisabledTooltip,
    canChangeDatabase = true,
    canSelectModel = true,
    canSelectTable = true,
    canSelectMetric = false,
    canSelectSavedQuestion = true,
    useOnlyAvailableDatabase = true,
    useOnlyAvailableSchema = true,
    availableModels,
    entityLookups,
    databases: propDatabases,
    hasLoadedDatabasesWithTablesSaved,
    hasLoadedDatabasesWithSaved,
    hasLoadedDatabasesWithTables,
    hasDataAccess: propHasDataAccess,
    hasNestedQueriesEnabled,
    selectedCardType,
    fetchDatabases,
    fetchFields,
    fetchQuestion,
    fetchSchemas,
    fetchSchemaTables,
    loading,
    loaded,
    allLoading,
  } = props;

  const [state, setState] = useState<DataSelectorState>(() => {
    const initialIds: SelectedIdsState & {
      selectedDataBucketId: DataPickerDataType | null;
      isSavedEntityPickerShown: boolean;
      savedEntityType: CardType | null;
      isPopoverOpen: boolean;
    } = {
      selectedDataBucketId: propSelectedDataBucketId ?? null,
      selectedDatabaseId: propSelectedDatabaseId ?? null,
      selectedSchemaId: propSelectedSchemaId ?? null,
      selectedTableId: propSelectedTableId ?? null,
      selectedFieldId: propSelectedFieldId ?? null,
      isSavedEntityPickerShown: false,
      savedEntityType: null,
      isPopoverOpen: Boolean(isInitiallyOpen && !readOnly),
    };
    const computedState = getComputedState(props, initialIds);
    return {
      activeStep: null,
      isLoading: false,
      isError: false,
      ...initialIds,
      ...computedState,
    };
  });

  const stateRef = useRef(state);
  stateRef.current = state;

  const propsRef = useRef(props);
  propsRef.current = props;

  const setStateWithComputedState = useCallback(
    (newState: Partial<DataSelectorState>, newProps = propsRef.current) => {
      return new Promise<void>((resolve) => {
        setState((prevState) => {
          const nextCombinedState = { ...prevState, ...newState };
          const computed = getComputedState(newProps, nextCombinedState);
          return {
            ...nextCombinedState,
            ...computed,
          };
        });
        resolve();
      });
    },
    [],
  );

  const prevPropsRef = useRef(props);
  useEffect(() => {
    const prevProps = prevPropsRef.current;
    const newState: Partial<DataSelectorState> = {};
    if (
      propSelectedDatabaseId !== prevProps.selectedDatabaseId &&
      stateRef.current.selectedDatabaseId !== propSelectedDatabaseId
    ) {
      newState.selectedDatabaseId = propSelectedDatabaseId ?? null;
    }
    if (
      propSelectedSchemaId !== prevProps.selectedSchemaId &&
      stateRef.current.selectedSchemaId !== propSelectedSchemaId
    ) {
      newState.selectedSchemaId = propSelectedSchemaId ?? null;
    }
    if (
      propSelectedTableId !== prevProps.selectedTableId &&
      stateRef.current.selectedTableId !== propSelectedTableId
    ) {
      newState.selectedTableId = propSelectedTableId ?? null;
    }
    if (
      propSelectedFieldId !== prevProps.selectedFieldId &&
      stateRef.current.selectedFieldId !== propSelectedFieldId
    ) {
      newState.selectedFieldId = propSelectedFieldId ?? null;
    }
    if (Object.keys(newState).length > 0) {
      setStateWithComputedState(newState, props);
    } else if (props.entityLookups !== prevProps.entityLookups) {
      setStateWithComputedState({}, props);
    }
    prevPropsRef.current = props;
  }, [
    propSelectedDatabaseId,
    propSelectedSchemaId,
    propSelectedTableId,
    propSelectedFieldId,
    props,
    setStateWithComputedState,
  ]);

  const isPopoverOpen = useCallback(() => {
    if (typeof isOpen === "boolean") {
      return isOpen;
    }
    return stateRef.current.isPopoverOpen;
  }, [isOpen]);

  const isSearchLoading = useCallback(() => {
    return propsRef.current.loading;
  }, []);

  const getCardType = useCallback((): CardType => {
    const { selectedDataBucketId, savedEntityType } = stateRef.current;
    switch (true) {
      case selectedDataBucketId === DATA_BUCKET.MODELS ||
        savedEntityType === "model":
        return "model";
      case selectedDataBucketId === DATA_BUCKET.METRICS ||
        savedEntityType === "metric":
        return "metric";
      default:
        return "question";
    }
  }, []);

  const hasModels = useCallback(() => {
    const { availableModels, canSelectModel, loaded } = propsRef.current;
    return loaded && !!canSelectModel && availableModels.includes("dataset");
  }, []);

  const hasUsableModels = useCallback(() => {
    return hasModels() && propsRef.current.hasNestedQueriesEnabled;
  }, [hasModels]);

  const hasMetrics = useCallback(() => {
    const { availableModels, canSelectMetric, loaded } = propsRef.current;
    return loaded && !!canSelectMetric && availableModels.includes("metric");
  }, []);

  const hasUsableMetrics = useCallback(() => {
    return hasMetrics() && propsRef.current.hasNestedQueriesEnabled;
  }, [hasMetrics]);

  const hasUsableModelsOrMetrics = useCallback(() => {
    return hasUsableModels() || hasUsableMetrics();
  }, [hasUsableModels, hasUsableMetrics]);

  const hasSavedQuestions = useCallback(() => {
    const { canSelectSavedQuestion } = propsRef.current;
    return (
      stateRef.current.databases.some((database) => database.is_saved_questions) &&
      !!canSelectSavedQuestion
    );
  }, []);

  const getDatabases = useCallback(() => {
    const { databases } = stateRef.current;
    const shouldRemoveSavedQuestionDatabaseFromList =
      !propsRef.current.hasNestedQueriesEnabled ||
      hasUsableModelsOrMetrics() ||
      !propsRef.current.canSelectSavedQuestion;

    return shouldRemoveSavedQuestionDatabaseFromList
      ? databases.filter((db) => !db.is_saved_questions)
      : databases;
  }, [hasUsableModelsOrMetrics]);

  const getNextStep = useCallback((): DataSelectorStep | null => {
    const { steps } = propsRef.current;
    const index = steps.findIndex((step) => step === stateRef.current.activeStep);
    return index < steps.length - 1 ? steps[index + 1] : null;
  }, []);

  const getPreviousStep = useCallback((): DataSelectorStep | null => {
    const { steps, useOnlyAvailableSchema } = propsRef.current;
    const { activeStep, schemas } = stateRef.current;
    if (isSearchLoading() || activeStep === null) {
      return null;
    }

    let index = steps.indexOf(activeStep);
    if (index === -1) {
      console.error(`Step ${activeStep} not found in ${steps}.`);
      return null;
    }

    index -= 1;

    if (
      steps[index] === SCHEMA_STEP &&
      useOnlyAvailableSchema &&
      schemas.length === 1
    ) {
      index -= 1;
    }

    if (steps[index] === DATA_BUCKET_STEP && !hasUsableModelsOrMetrics()) {
      return null;
    }

    if (index < 0) {
      return null;
    }
    return steps[index];
  }, [isSearchLoading, hasUsableModelsOrMetrics]);

  const getClearedStateForStep = useCallback(
    (step: DataSelectorStep): Partial<DataSelectorState> => {
      if (step === DATA_BUCKET_STEP) {
        return {
          selectedDataBucketId: null,
          selectedDatabaseId: null,
          selectedSchemaId: null,
          selectedTableId: null,
          selectedFieldId: null,
        };
      } else if (step === DATABASE_STEP) {
        return {
          selectedDatabaseId: null,
          selectedSchemaId: null,
          selectedTableId: null,
          selectedFieldId: null,
        };
      } else if (step === SCHEMA_STEP) {
        return {
          selectedSchemaId: null,
          selectedTableId: null,
          selectedFieldId: null,
        };
      } else if (step === TABLE_STEP) {
        return {
          selectedTableId: null,
          selectedFieldId: null,
        };
      } else if (step === FIELD_STEP) {
        return {
          selectedFieldId: null,
        };
      }
      return {};
    },
    [],
  );

  const hasPreloadedStepData = useCallback(
    (stepName: DataSelectorStep): boolean => {
      const {
        hasLoadedDatabasesWithTables,
        hasLoadedDatabasesWithTablesSaved,
        hasLoadedDatabasesWithSaved,
      } = propsRef.current;
      if (stepName === DATABASE_STEP) {
        return hasLoadedDatabasesWithTablesSaved || hasLoadedDatabasesWithSaved;
      } else if (stepName === SCHEMA_STEP || stepName === TABLE_STEP) {
        return (
          hasLoadedDatabasesWithTablesSaved ||
          (hasLoadedDatabasesWithTables &&
            !stateRef.current.selectedDatabase?.is_saved_questions)
        );
      } else if (stepName === FIELD_STEP) {
        return stateRef.current.fields.length > 0;
      }
      return false;
    },
    [],
  );

  const loadStepData = useCallback(
    async (stepName: DataSelectorStep) => {
      const currentProps = propsRef.current;
      const currentState = stateRef.current;
      const loadersForSteps: Record<
        DataSelectorStep,
        (() => Promise<unknown> | undefined) | undefined
      > = {
        [DATA_BUCKET_STEP]: () => {
          return Promise.all([
            currentProps.fetchDatabases(currentProps.databaseQuery),
            currentProps.fetchDatabases({ saved: true }),
          ]);
        },
        [DATABASE_STEP]: () => {
          return Promise.all([
            currentProps.fetchDatabases(currentProps.databaseQuery),
            currentProps.fetchDatabases({ saved: true }),
          ]);
        },
        [SCHEMA_STEP]: () => {
          return Promise.all([
            currentProps.fetchDatabases(currentProps.databaseQuery),
            currentState.selectedDatabaseId != null
              ? currentProps.fetchSchemas(currentState.selectedDatabaseId)
              : undefined,
          ]);
        },
        [TABLE_STEP]: () => {
          if (currentState.selectedSchemaId != null) {
            return currentProps.fetchSchemaTables(currentState.selectedSchemaId);
          } else if (currentState.selectedSchema?.id != null) {
            return currentProps.fetchSchemaTables(currentState.selectedSchema.id);
          }
        },
        [FIELD_STEP]: () => {
          if (currentState.selectedTableId != null) {
            return currentProps.fetchFields(currentState.selectedTableId);
          }
        },
      };

      const loader = loadersForSteps[stepName];
      if (loader) {
        try {
          await setStateWithComputedState({
            isLoading: true,
            isError: false,
          });
          await loader();
          await setStateWithComputedState({
            isLoading: false,
            isError: false,
          });
        } catch (e) {
          await setStateWithComputedState({
            isLoading: false,
            isError: true,
          });
        }
      }
    },
    [setStateWithComputedState],
  );

  const showSavedEntityPicker = useCallback(
    ({ entityType }: { entityType?: CardType }) =>
      setState((prev) => ({
        ...prev,
        isSavedEntityPickerShown: true,
        savedEntityType: entityType ?? null,
      })),
    [],
  );

  const switchToStepRef = useRef<
    (
      stepName: DataSelectorStep,
      stateChange?: Partial<DataSelectorState>,
      skipSteps?: boolean,
    ) => Promise<void>
  >(async () => {});

  const nextStepRef = useRef<
    (stateChange?: Partial<DataSelectorState>, skipSteps?: boolean) => Promise<void>
  >(async () => {});

  const previousStepRef = useRef<() => void>(() => {});

  const onChangeDatabaseRef = useRef<
    (database: DataSelectorDatabase) => Promise<void>
  >(async () => {});

  const onChangeSchemaRef = useRef<
    (schema?: DataSelectorSchema) => Promise<void>
  >(async () => {});

  const onChangeTableRef = useRef<
    (table?: DataSelectorTable) => Promise<void>
  >(async () => {});

  const onChangeFieldRef = useRef<
    (field?: DataSelectorField) => Promise<void>
  >(async () => {});

  const skipSteps = useCallback(() => {
    const { readOnly, databaseIsDisabled, useOnlyAvailableDatabase, useOnlyAvailableSchema } =
      propsRef.current;
    const { activeStep, schemas } = stateRef.current;

    if (readOnly) {
      return;
    }

    if (
      activeStep === DATABASE_STEP &&
      useOnlyAvailableDatabase &&
      propsRef.current.selectedDatabaseId == null
    ) {
      const databases = getDatabases();
      const enabledDatabases = databases.filter(
        (db) => !databaseIsDisabled?.(db),
      );
      if (enabledDatabases.length >= 1) {
        onChangeDatabaseRef.current(enabledDatabases[0]);
      }
    }
    if (
      activeStep === SCHEMA_STEP &&
      useOnlyAvailableSchema &&
      propsRef.current.selectedSchemaId == null
    ) {
      if (schemas && schemas.length === 1) {
        onChangeSchemaRef.current(schemas[0]);
      }
    }
  }, [getDatabases]);

  const switchToStep = useCallback(
    async (
      stepName: DataSelectorStep,
      stateChange: Partial<DataSelectorState> = {},
      shouldSkipSteps = true,
    ) => {
      await setStateWithComputedState({
        ...stateChange,
        activeStep: stepName,
      });
      if (!hasPreloadedStepData(stepName)) {
        await loadStepData(stepName);
      }
      if (shouldSkipSteps) {
        skipSteps();
      }
    },
    [hasPreloadedStepData, loadStepData, setStateWithComputedState, skipSteps],
  );
  switchToStepRef.current = switchToStep;

  const nextStep = useCallback(
    async (stateChange: Partial<DataSelectorState> = {}, shouldSkipSteps = true) => {
      const next = getNextStep();
      if (!next) {
        await setStateWithComputedState({
          ...stateChange,
          isPopoverOpen: false,
        });
      } else {
        await switchToStep(next, stateChange, shouldSkipSteps);
      }
    },
    [getNextStep, setStateWithComputedState, switchToStep],
  );
  nextStepRef.current = nextStep;

  const previousStep = useCallback(() => {
    const prev = getPreviousStep();
    if (prev) {
      const clearedState = getClearedStateForStep(prev);
      switchToStep(prev, clearedState, false);
    }
  }, [getClearedStateForStep, getPreviousStep, switchToStep]);
  previousStepRef.current = previousStep;

  const onChangeDatabase = useCallback(
    async (database: DataSelectorDatabase) => {
      if (database.is_saved_questions) {
        showSavedEntityPicker({ entityType: "question" });
        return;
      }

      if (propsRef.current.setDatabaseFn) {
        propsRef.current.setDatabaseFn(database.id);
      }

      if (stateRef.current.selectedDatabaseId != null) {
        await previousStep();
      }
      await nextStep({ selectedDatabaseId: database && database.id });
    },
    [nextStep, previousStep, showSavedEntityPicker],
  );
  onChangeDatabaseRef.current = onChangeDatabase;

  const onChangeSchema = useCallback(
    async (schema?: DataSelectorSchema) => {
      await nextStep({ selectedSchemaId: schema?.id ?? null });
    },
    [nextStep],
  );
  onChangeSchemaRef.current = onChangeSchema;

  const onChangeTable = useCallback(
    async (table?: DataSelectorTable) => {
      if (propsRef.current.setSourceTableFn && table?.id != null) {
        propsRef.current.setSourceTableFn(table.id, table.db_id);
      }
      await nextStep({ selectedTableId: table?.id ?? null });
    },
    [nextStep],
  );
  onChangeTableRef.current = onChangeTable;

  const onChangeField = useCallback(
    async (field?: DataSelectorField) => {
      const fieldId = field?.id;
      if (propsRef.current.setFieldFn && typeof fieldId === "number") {
        propsRef.current.setFieldFn(fieldId);
      }
      await nextStep({ selectedFieldId: fieldId ?? null });
    },
    [nextStep],
  );
  onChangeFieldRef.current = onChangeField;

  const onChangeDataBucket = useCallback(
    async (selectedDataBucketId: DataPickerDataType) => {
      if (selectedDataBucketId === DATA_BUCKET.RAW_DATA) {
        await switchToStep(DATABASE_STEP, { selectedDataBucketId });
        return;
      }
      await switchToStep(
        DATABASE_STEP,
        {
          selectedDataBucketId,
        },
        false,
      );
      const database = propsRef.current.databases.find((db) => db.is_saved_questions);
      if (database) {
        onChangeDatabase(database);
      }
    },
    [onChangeDatabase, switchToStep],
  );

  const isSavedEntitySelected = useCallback(
    () => isVirtualCardId(propsRef.current.selectedTableId),
    [],
  );

  const hydrateActiveStep = useCallback(async () => {
    const { steps } = propsRef.current;
    const currentState = stateRef.current;
    if (
      isSavedEntitySelected() ||
      currentState.selectedDataBucketId === DATA_BUCKET.MODELS ||
      currentState.selectedDataBucketId === DATA_BUCKET.SAVED_QUESTIONS
    ) {
      await switchToStep(DATABASE_STEP);
    } else if (currentState.selectedTableId && steps.includes(FIELD_STEP)) {
      await switchToStep(FIELD_STEP);
    } else if (
      (currentState.selectedSchemaId || currentState.selectedSchema?.id) &&
      steps.includes(TABLE_STEP)
    ) {
      await switchToStep(TABLE_STEP);
    } else if (currentState.selectedDatabaseId && steps.includes(SCHEMA_STEP)) {
      await switchToStep(SCHEMA_STEP);
    } else if (
      steps[0] === DATA_BUCKET_STEP &&
      !hasUsableModelsOrMetrics()
    ) {
      await switchToStep(steps[1]);
    } else {
      await switchToStep(steps[0]);
    }
  }, [hasUsableModelsOrMetrics, isSavedEntitySelected, switchToStep]);

  useEffect(() => {
    const mount = async () => {
      const currentProps = propsRef.current;
      const { fetchFields, fetchQuestion, selectedDataBucketId, selectedTableId: sourceId } =
        currentProps;

      if (!isSearchLoading() && !stateRef.current.activeStep) {
        await hydrateActiveStep();
      }

      if (selectedDataBucketId === DATA_BUCKET.MODELS) {
        showSavedEntityPicker({ entityType: "model" });
      }

      if (sourceId) {
        await fetchFields(sourceId);
        if (isSavedEntitySelected()) {
          await fetchQuestion(sourceId);

          showSavedEntityPicker({
            entityType: currentProps.selectedCardType,
          });
        }
      }
    };
    mount();
  }, [hydrateActiveStep, isSavedEntitySelected, isSearchLoading, showSavedEntityPicker]);

  const prevAllLoadingRef = useRef(allLoading);
  useEffect(() => {
    const prevAllLoading = prevAllLoadingRef.current;
    prevAllLoadingRef.current = allLoading;
    const loadedDatasets = prevAllLoading && !allLoading;

    const checkUpdates = async () => {
      if (loadedDatasets) {
        await hydrateActiveStep();
      }

      const {
        activeStep,
        selectedDatabase,
        selectedSchema,
        selectedTable,
        selectedField,
        schemas,
      } = stateRef.current;

      const { entityLookups, useOnlyAvailableSchema, readOnly, selectedSchemaId } =
        propsRef.current;
      const selectedSchemaDatabase = selectedSchema
        ? entityLookups.database(selectedSchema.database)
        : undefined;

      const invalidSchema =
        selectedDatabase &&
        selectedSchema &&
        selectedSchemaDatabase &&
        selectedSchemaDatabase.id !== selectedDatabase.id &&
        selectedSchemaDatabase.id !== SAVED_QUESTIONS_VIRTUAL_DB_ID;

      const onStepMissingSchemaAndTable =
        !selectedSchema &&
        !selectedTable &&
        (activeStep === TABLE_STEP || activeStep === FIELD_STEP);

      const onStepMissingTable = !selectedTable && activeStep === FIELD_STEP;

      const invalidTable =
        selectedSchema &&
        selectedTable &&
        !isVirtualCardId(selectedTable.id) &&
        entityLookups.tableSchema(selectedTable.id)?.id !== selectedSchema.id;

      const invalidField =
        selectedTable &&
        selectedField &&
        selectedField.table_id !== selectedTable.id;

      const onStepMissingOnlySchemaSelection =
        activeStep === SCHEMA_STEP &&
        !selectedSchema &&
        useOnlyAvailableSchema &&
        !readOnly &&
        selectedSchemaId == null &&
        stateRef.current.selectedSchemaId == null &&
        schemas.length === 1;

      if (invalidSchema || onStepMissingSchemaAndTable) {
        await switchToStep(SCHEMA_STEP, {
          selectedSchemaId: null,
          selectedTableId: null,
          selectedFieldId: null,
        });
      } else if (invalidTable || onStepMissingTable) {
        await switchToStep(TABLE_STEP, {
          selectedTableId: null,
          selectedFieldId: null,
        });
      } else if (invalidField) {
        await switchToStep(FIELD_STEP, { selectedFieldId: null });
      } else if (onStepMissingOnlySchemaSelection) {
        await onChangeSchema(schemas[0]);
      }
    };

    checkUpdates();
  }, [allLoading, hydrateActiveStep, onChangeSchema, switchToStep]);

  const togglePopoverOpen = useCallback(() => {
    setStateWithComputedState({
      isPopoverOpen: !stateRef.current.isPopoverOpen,
    });
  }, [setStateWithComputedState]);

  const handleSavedEntityPickerClose = useCallback(() => {
    const { selectedDataBucketId } = stateRef.current;
    if (selectedDataBucketId === DATA_BUCKET.MODELS || hasUsableModels()) {
      previousStep();
    }
    if (
      selectedDataBucketId === DATA_BUCKET.METRICS ||
      hasUsableMetrics()
    ) {
      previousStep();
    }
    setState((prev) => ({
      ...prev,
      isSavedEntityPickerShown: false,
      savedEntityType: null,
    }));
  }, [hasUsableMetrics, hasUsableModels, previousStep]);

  const handleClose = useCallback(() => {
    const { onClose } = propsRef.current;
    if (typeof onClose === "function") {
      onClose();
    }
  }, []);

  const handleDismiss = useCallback(() => {
    handleClose();
    setStateWithComputedState({
      isPopoverOpen: false,
    });
  }, [handleClose, setStateWithComputedState]);

  const handleSavedEntitySelect = useCallback(
    async (tableOrCardId: string) => {
      await propsRef.current.fetchFields(tableOrCardId);
      if (propsRef.current.setSourceTableFn) {
        const table = propsRef.current.entityLookups.table(tableOrCardId);
        propsRef.current.setSourceTableFn(tableOrCardId, table?.db_id);
      }
      togglePopoverOpen();
      handleClose();
    },
    [handleClose, togglePopoverOpen],
  );

  const hasDataAccess = useCallback(() => {
    const { hasDataAccess, databases } = propsRef.current;
    return hasDataAccess || databases?.length > 0;
  }, []);

  const getTriggerClasses = useCallback(() => {
    const { readOnly, triggerClasses } = propsRef.current;
    return cx(triggerClasses ?? cx(CS.flex, CS.alignCenter), {
      disabled: readOnly,
    });
  }, []);

  const getTriggerElement = useCallback(() => {
    const {
      className,
      style,
      triggerIconSize,
      triggerElement,
      getTriggerElementContent: TriggerComponent,
      hasTriggerExpandControl,
      readOnly,
      isMantine,
    } = propsRef.current;

    if (triggerElement) {
      return triggerElement;
    }

    const { selectedDatabase, selectedTable, selectedField } = stateRef.current;

    const hasMultipleSchemas =
      selectedField != null &&
      selectedDatabase != null &&
      _.uniq(
        propsRef.current.entityLookups.databaseTables(selectedDatabase.id),
        (table) => table.schema_name,
      ).length > 1;

    return (
      <Trigger
        className={className}
        style={style}
        showDropdownIcon={!readOnly && hasTriggerExpandControl}
        iconSize={isMantine ? "1rem" : triggerIconSize}
        isMantine={isMantine}
      >
        {TriggerComponent && (
          <TriggerComponent
            database={selectedDatabase}
            table={selectedTable}
            field={selectedField}
            hasMultipleSchemas={hasMultipleSchemas}
          />
        )}
      </Trigger>
    );
  }, []);

  const renderActiveStep = () => {
    const { steps, combineDatabaseSchemaSteps, hasNestedQueriesEnabled } =
      propsRef.current;
    const hasNextStep = getNextStep() != null;
    const hasPreviousStep = getPreviousStep() != null;
    const hasBackButton =
      hasPreviousStep &&
      steps.includes(DATA_BUCKET_STEP) &&
      hasUsableModelsOrMetrics();

    const stepProps = {
      ...state,
      databases: getDatabases(),
      selectedDatabase: state.selectedDatabase ?? undefined,
      selectedSchema: state.selectedSchema ?? undefined,
      selectedTable: state.selectedTable ?? undefined,
      selectedField: state.selectedField ?? undefined,
      selectedSchemaId: state.selectedSchemaId ?? undefined,

      onChangeDataBucket,
      onChangeDatabase,
      onChangeSchema,
      onChangeTable,
      onChangeField,

      isLoading: state.isLoading,
      hasNextStep,
      onBack: hasPreviousStep ? previousStep : undefined,
      hasFiltering: true,
      hasInitialFocus: true,
      databaseIsDisabled,
      databaseDisabledTooltip,
      getDatabaseSchemas: entityLookups.databaseSchemas,
      getFieldDisplayName: entityLookups.fieldName,
    };

    switch (state.activeStep) {
      case DATA_BUCKET_STEP:
        return (
          <Box p="sm">
            <DataSelectorDataBucketPicker
              dataTypes={getDataTypes({
                hasModels: hasModels(),
                hasTables: !!canSelectTable,
                hasNestedQueriesEnabled,
                hasSavedQuestions: hasSavedQuestions(),
                hasMetrics: hasMetrics(),
              })}
              {...stepProps}
            />
          </Box>
        );
      case DATABASE_STEP:
        return combineDatabaseSchemaSteps ? (
          <DataSelectorDatabaseSchemaPicker
            {...stepProps}
            hasBackButton={hasBackButton}
          />
        ) : (
          <DataSelectorDatabasePicker {...stepProps} />
        );
      case SCHEMA_STEP:
        return combineDatabaseSchemaSteps ? (
          <DataSelectorDatabaseSchemaPicker
            {...stepProps}
            hasBackButton={hasBackButton}
          />
        ) : (
          <DataSelectorSchemaPicker {...stepProps} />
        );
      case TABLE_STEP:
        return <DataSelectorTablePicker {...stepProps} />;
      case FIELD_STEP:
        return <DataSelectorFieldPicker {...stepProps} />;
    }

    return null;
  };

  const renderContent = () => {
    const { isSavedEntityPickerShown, selectedDataBucketId, selectedTable } =
      state;
    const { canChangeDatabase, selectedDatabaseId, selectedCollectionId } =
      props;

    const currentDatabaseId = canChangeDatabase ? null : selectedDatabaseId;

    const isPickerOpen =
      isSavedEntityPickerShown || selectedDataBucketId === DATA_BUCKET.MODELS;

    if (isSearchLoading()) {
      return <LoadingAndErrorWrapper loading />;
    }

    if (hasDataAccess()) {
      if (isPickerOpen) {
        return (
          <SavedEntityPicker
            collectionId={selectedCollectionId}
            type={getCardType()}
            tableId={
              typeof selectedTable?.id === "string"
                ? selectedTable.id
                : undefined
            }
            databaseId={currentDatabaseId}
            onSelect={handleSavedEntitySelect}
            onBack={handleSavedEntityPickerClose}
          />
        );
      }

      return renderActiveStep();
    }

    return (
      <Box w={CONTAINER_WIDTH} p="80px 60px">
        <EmptyState
          message={t`To pick some data, you'll need to add some first`}
          icon="database"
        />
      </Box>
    );
  };

  if (isPopover) {
    const triggerElement = getTriggerElement();

    const triggerTargetClassName = cx(
      containerClassName,
      getTriggerClasses(),
    );

    return (
      <Popover
          onClose={handleClose}
          onDismiss={handleDismiss}
          position="bottom-start"
          opened={isPopoverOpen()}
          disabled={readOnly}
        >
          <Popover.Target>
            <Box
              className={triggerTargetClassName}
              onClick={() => togglePopoverOpen()}
            >
              {triggerElement}
            </Box>
          </Popover.Target>

          <Popover.Dropdown>{renderContent()}</Popover.Dropdown>
        </Popover>
    );
  }

  return renderContent();
}

UnconnectedDataSelector.defaultProps = {
  isInitiallyOpen: false,
  useOnlyAvailableDatabase: true,
  useOnlyAvailableSchema: true,
  canChangeDatabase: true,
  hasTriggerExpandControl: true,
  isPopover: true,
  isMantine: false,
  canSelectModel: true,
  canSelectTable: true,
  canSelectMetric: false,
  canSelectSavedQuestion: true,
};

type ConnectOwnProps = DataSelectorOwnProps &
  SchemaFetchersProps &
  AvailableModelsInjectedProps & {
    availableModelsResult?: AvailableModelsResult;
  };

type WithoutSchemaFetchers = Omit<ConnectOwnProps, keyof SchemaFetchersProps>;

function withSchemaFetchers(
  WrappedComponent: ComponentType<ConnectOwnProps>,
): ComponentType<WithoutSchemaFetchers> {
  return function DataSelectorWithSchemaFetchers(props: WithoutSchemaFetchers) {
    const [triggerListSchemas] = useLazyListDatabaseSchemasQuery();
    const [triggerListSchemaTables] = useLazyListDatabaseSchemaTablesQuery();

    const fetchSchemas = useCallback(
      (databaseId: DatabaseId) =>
        triggerListSchemas({ id: databaseId, "can-query": true }).unwrap(),
      [triggerListSchemas],
    );

    const fetchSchemaTables = useCallback(
      (schemaId: SchemaId) => {
        const [dbId, schema] = parseSchemaId(schemaId);
        return triggerListSchemaTables({
          id: dbId,
          schema,
          "can-query": true,
        }).unwrap();
      },
      [triggerListSchemaTables],
    );

    return (
      <WrappedComponent
        {...props}
        fetchSchemas={fetchSchemas}
        fetchSchemaTables={fetchSchemaTables}
      />
    );
  };
}

function withAvailableModels(
  WrappedComponent: ComponentType<WithoutSchemaFetchers>,
): ComponentType<DataSelectorOwnProps> {
  return function DataSelectorWithAvailableModels(props: DataSelectorOwnProps) {
    const { data: response, isLoading } = useSearchQuery({
      calculate_available_models: true,
      limit: 0,
      models: ["dataset", "metric"],
      context: "data-picker",
    });
    let availableModelsResult: AvailableModelsResult | undefined;
    if (response) {
      const { data: _data, ...rest } = response;
      availableModelsResult = rest;
    }
    return (
      <WrappedComponent
        {...props}
        availableModelsResult={availableModelsResult}
        loading={isLoading}
        loaded={!isLoading && response != null}
        allLoading={isLoading}
      />
    );
  };
}

function withDatabaseList(
  WrappedComponent: ComponentType<DataSelectorOwnProps>,
): ComponentType<DataSelectorOwnProps> {
  return function DataSelectorWithDatabaseList(props: DataSelectorOwnProps) {
    useListDatabasesQuery({ "can-query": true });
    return <WrappedComponent {...props} />;
  };
}

const isListDatabasesQuerySuccess = (
  state: State,
  query: ListDatabasesRequest,
) => databaseApi.endpoints.listDatabases.select(query)(state).isSuccess;

const mapStateToProps = (
  state: State,
  ownProps: ConnectOwnProps,
): DataSelectorStateProps => {
  const databaseQuery: ListDatabasesRequest = {
    ...ownProps.databaseQuery,
    "can-query": true,
  };
  const queriedDatabases =
    databaseApi.endpoints.listDatabases.select(databaseQuery)(state).data?.data;
  const entityLookups = getEntityLookups(state);
  const selectedCardId = getQuestionIdFromVirtualTableId(
    ownProps.selectedTableId,
  );
  return {
    availableModels: ownProps.availableModelsResult?.available_models ?? [],
    entityLookups,
    databases:
      ownProps.databases ||
      queriedDatabases
        ?.map(({ id }) => entityLookups.database(id))
        .filter((database) => database != null) ||
      [],
    hasLoadedDatabasesWithTablesSaved: isListDatabasesQuerySuccess(state, {
      include: "tables",
      saved: true,
      "can-query": true,
    }),
    hasLoadedDatabasesWithSaved: isListDatabasesQuerySuccess(state, {
      saved: true,
      "can-query": true,
    }),
    hasLoadedDatabasesWithTables: isListDatabasesQuerySuccess(state, {
      include: "tables",
      "can-query": true,
    }),
    hasDataAccess: canUserCreateQueries(state),
    hasNestedQueriesEnabled: getSetting(state, "enable-nested-queries"),
    selectedCardType:
      selectedCardId != null
        ? getShallowQuestions(state)[selectedCardId]?.type
        : undefined,
  };
};

const mapDispatchToProps = (dispatch: Dispatch): DataSelectorDispatchProps => ({
  fetchDatabases: (databaseQuery) =>
    runRtkEndpoint(
      { ...databaseQuery, "can-query": true },
      dispatch,
      databaseApi.endpoints.listDatabases,
      { forceRefetch: false },
    ),
  fetchFields: (tableId) =>
    Promise.resolve(dispatch(fetchTableMetadata({ id: tableId }))),
  fetchQuestion: (id) =>
    runRtkEndpoint(
      { id: getQuestionIdFromVirtualTableId(id) },
      dispatch,
      cardApi.endpoints.getCard,
    ),
});

const DataSelector = withDatabaseList(
  withAvailableModels(
    withSchemaFetchers(
      connect(mapStateToProps, mapDispatchToProps)(UnconnectedDataSelector),
    ),
  ),
);