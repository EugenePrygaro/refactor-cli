import cx from "classnames";
import debounce from "lodash.debounce";
import type {
  CSSProperties,
  ComponentType,
  ForwardedRef,
  MutableRefObject,
  PropsWithoutRef,
} from "react";
import React, {
  Component,
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from "react";
import { flushSync } from "react-dom";
import _ from "underscore";
import CS from "metabase/css/core/index.css";
import { isCypressActive } from "metabase/env";
import { delay } from "metabase/utils/delay";
import resizeObserver from "metabase/utils/resize-observer";

const WAIT_TIME = delay(300);

export const ExplicitSizeRefreshModeContext = createContext<
  RefreshMode | undefined
>(undefined);

const REFRESH_MODE = {
  throttle: (fn: () => void) => _.throttle(fn, WAIT_TIME),
  debounce: (fn: () => void) => debounce(fn, WAIT_TIME),
  debounceLeading: (fn: () => void) =>
    debounce(fn, WAIT_TIME, { leading: true }),
  none: (fn: () => void) => fn,
  layout: (fn: () => void) => () => flushSync(fn),
};

export type RefreshMode = keyof typeof REFRESH_MODE;

interface ExplicitSizeProps<T> {
  selector?: string;
  wrapped?: boolean;
  refreshMode?: RefreshMode | ((props: T) => RefreshMode);
}

type ExplicitSizeState = {
  width: number | null;
  height: number | null;
};

type InnerProps = {
  forwardedRef: ForwardedRef<unknown>;
  className?: string;
  style?: CSSProperties;
  onUpdateSize?: () => void;
};

type ExplicitSizeOuterProps<T> = Omit<T, "width" | "height">;

export function ExplicitSize<T>({
  selector,
  wrapped = false,
  refreshMode = "throttle",
}: ExplicitSizeProps<T> = {}) {
  return (ComposedComponent: ComponentType<T & ExplicitSizeState>) => {
    const displayName = ComposedComponent.displayName || ComposedComponent.name;

    const thisObj: any = {
      state: {
        width: null,
        height: null,
      },
    };

    const WrappedComponentImpl = function (
      this: any,
      allProps: T & InnerProps
    ) {
      const { forwardedRef, ...props } = allProps;

      const [state, setState] = useState<ExplicitSizeState>({
        width: null,
        height: null,
      });

      const context = useContext(ExplicitSizeRefreshModeContext);

      const elementRef = useRef<HTMLDivElement | null>(null);
      const currentElementRef = useRef<Element | null>(null);
      const timeoutIdRef = useRef<ReturnType<typeof setTimeout> | null>(null);
      const onUpdateSizeCallbackRef = useRef<(() => void) | null>(null);

      const propsRef = useRef(allProps);
      propsRef.current = allProps;

      const stateRef = useRef(state);
      stateRef.current = state;

      const contextRef = useRef(context);
      contextRef.current = context;

      const printMediaQuery = useMemo(() => {
        return typeof window !== "undefined" && window.matchMedia
          ? window.matchMedia("print")
          : null;
      }, []);

      const getRefreshMode = useCallback(() => {
        if (contextRef.current) {
          return contextRef.current as RefreshMode;
        }

        const calculatedRefreshMode =
          typeof refreshMode === "function"
            ? refreshMode(propsRef.current)
            : refreshMode;
        if (
          calculatedRefreshMode !== "layout" &&
          (isCypressActive || printMediaQuery?.matches)
        ) {
          return "none";
        }

        return calculatedRefreshMode;
      }, [printMediaQuery]);

      const refreshModeValueRef = useRef<RefreshMode>(
        WAIT_TIME === 0
          ? "none"
          : typeof refreshMode === "string"
          ? refreshMode
          : "throttle"
      );

      const updateSizeRef = useRef<((entry?: ResizeObserverEntry) => void) | null>(
        null
      );

      const _getElement = useCallback(() => {
        try {
          let element: Element | null = elementRef.current;
          if (selector && element instanceof Element) {
            element = element.querySelector(selector) || element;
          }

          return element instanceof Element ? element : null;
        } catch (e) {
          console.error(e);
          return null;
        }
      }, []);

      const __updateSize = useCallback(
        (entry?: ResizeObserverEntry) => {
          const element = _getElement();
          if (!element) {
            return;
          }

          let width: number;
          let height: number;

          if (entry && entry.target === element) {
            const box = entry.borderBoxSize?.[0];
            width = box ? box.inlineSize : entry.contentRect.width;
            height = box ? box.blockSize : entry.contentRect.height;
          } else if (
            printMediaQuery?.matches &&
            element instanceof HTMLElement
          ) {
            width = element.offsetWidth;
            height = element.offsetHeight;
          } else {
            const rect = element.getBoundingClientRect();
            width = rect.width;
            height = rect.height;
          }

          if (!width && !height) {
            return;
          }

          const { width: prevWidth, height: prevHeight } = stateRef.current;

          const hasChanged =
            prevWidth === null ||
            prevHeight === null ||
            Math.abs(prevWidth - width) >= 1 ||
            Math.abs(prevHeight - height) >= 1;

          if (hasChanged) {
            stateRef.current = { width, height };
            onUpdateSizeCallbackRef.current = () => {
              propsRef.current?.onUpdateSize?.();
            };
            setState({ width, height });
          }
        },
        [_getElement, printMediaQuery]
      );

      if (!updateSizeRef.current) {
        const refreshFn = REFRESH_MODE[getRefreshMode()];
        updateSizeRef.current = refreshFn(__updateSize);
      }

      const updateResizeObserver = useCallback(() => {
        const element = _getElement();
        if (currentElementRef.current !== element) {
          if (currentElementRef.current && updateSizeRef.current) {
            resizeObserver.unsubscribe(
              currentElementRef.current,
              updateSizeRef.current
            );
          }
          currentElementRef.current = element;
          if (currentElementRef.current && updateSizeRef.current) {
            resizeObserver.subscribe(
              currentElementRef.current,
              updateSizeRef.current
            );
          }
        }
      }, [_getElement]);

      const updateRefreshMode = useCallback(() => {
        const nextMode = getRefreshMode();
        if (nextMode === refreshModeValueRef.current) {
          return;
        }
        if (currentElementRef.current && updateSizeRef.current) {
          resizeObserver.unsubscribe(
            currentElementRef.current,
            updateSizeRef.current
          );
        }
        const refreshFn = REFRESH_MODE[nextMode];
        updateSizeRef.current = refreshFn(__updateSize);
        if (currentElementRef.current && updateSizeRef.current) {
          resizeObserver.subscribe(
            currentElementRef.current,
            updateSizeRef.current
          );
        }
        refreshModeValueRef.current = nextMode;
      }, [getRefreshMode, __updateSize]);

      const _setElementRef = useCallback((el: HTMLDivElement | null) => {
        const { forwardedRef } = propsRef.current;
        if (forwardedRef) {
          if (typeof forwardedRef === "function") {
            forwardedRef(el);
          } else {
            (forwardedRef as MutableRefObject<unknown>).current = el;
          }
        }

        const elementAttached = el != null && elementRef.current == null;
        elementRef.current = el;
        if (elementAttached) {
          if (timeoutIdRef.current !== null) {
            clearTimeout(timeoutIdRef.current);
          }
          timeoutIdRef.current = setTimeout(() => {
            updateSizeRef.current?.();
          }, 0);
        }
      }, []);

      useEffect(() => {
        if (onUpdateSizeCallbackRef.current) {
          const cb = onUpdateSizeCallbackRef.current;
          onUpdateSizeCallbackRef.current = null;
          cb();
        }
      });

      useEffect(() => {
        const updateSizeAndRefreshMode = () => {
          updateRefreshMode();
          updateSizeRef.current?.();
        };

        printMediaQuery?.addEventListener("change", updateSizeAndRefreshMode);

        const el = _getElement();
        currentElementRef.current = el;
        if (el && updateSizeRef.current) {
          resizeObserver.subscribe(el, updateSizeRef.current);
        }

        timeoutIdRef.current = setTimeout(() => {
          updateSizeRef.current?.();
        }, 0);

        return () => {
          if (currentElementRef.current && updateSizeRef.current) {
            resizeObserver.unsubscribe(
              currentElementRef.current,
              updateSizeRef.current
            );
          }
          printMediaQuery?.removeEventListener("change", updateSizeAndRefreshMode);
          if (timeoutIdRef.current !== null) {
            clearTimeout(timeoutIdRef.current);
          }
        };
      }, [_getElement, printMediaQuery, updateRefreshMode]);

      const isInitialMount = useRef(true);
      useEffect(() => {
        if (isInitialMount.current) {
          isInitialMount.current = false;
          return;
        }

        if (!currentElementRef.current) {
          if (timeoutIdRef.current !== null) {
            clearTimeout(timeoutIdRef.current);
          }
          timeoutIdRef.current = setTimeout(() => {
            updateSizeRef.current?.();
          }, 0);
        }

        updateResizeObserver();
        updateRefreshMode();
      });

      const currentThis = this || thisObj;
      currentThis.state = state;
      currentThis.props = allProps;
      currentThis.elementRef = elementRef;
      currentThis._setElementRef = _setElementRef;
      thisObj.state = state;
      thisObj.props = allProps;
      thisObj.elementRef = elementRef;
      thisObj._setElementRef = _setElementRef;

      if (wrapped) {
        const { className, style = {}, ...rest } = props as any;
        const { width, height } = state;
        return (
          <div
              className={cx(className, CS.relative)}
              style={style}
              ref={elementRef}
            >
              <ComposedComponent
                ref={forwardedRef}
                style={{ position: "absolute", top: 0, left: 0, width, height }}
                // Unjustified type cast. FIXME
                {...(rest as unknown as T)}
                {...this.state}
              />
            </div>
        );
      } else {
        return (
          <ComposedComponent
              ref={_setElementRef}
              // Unjustified type cast. FIXME
              {...(props as unknown as T)}
              {...this.state}
            />
        );
      }
    };

    const WrappedComponent = WrappedComponentImpl.bind(thisObj);
    (WrappedComponent as any).displayName = `ExplicitSize[${displayName}]`;

    return React.forwardRef<
      unknown,
      PropsWithoutRef<ExplicitSizeOuterProps<T>>
    >((props, ref) => (
      <WrappedComponent {...(props as T & InnerProps)} forwardedRef={ref} />
    ));
  };
}