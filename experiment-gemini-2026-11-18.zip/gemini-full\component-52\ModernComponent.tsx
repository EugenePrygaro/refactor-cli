import React, {useEffect, useState} from 'react';
import {defineMessages} from 'react-intl';
import type {IncomingWebhook} from '@mattermost/types/integrations';
import type {Team} from '@mattermost/types/teams';
import type {ActionResult} from 'mattermost-redux/types/actions';
import AbstractIncomingWebhook from 'components/integrations/abstract_incoming_webhook';
import LoadingScreen from 'components/loading_screen';
import {getHistory} from 'utils/browser_history';

const messages = defineMessages({
    footer: {
        id: 'update_incoming_webhook.update',
        defaultMessage: 'Update',
    },
    header: {
        id: 'integrations.edit',
        defaultMessage: 'Edit',
    },
    loading: {
        id: 'update_incoming_webhook.updating',
        defaultMessage: 'Updating...',
    },
});

type Props = {

    /**
     * The current team
     */
    team: Team;

    /**
     * The incoming webhook to edit
     */
    hook?: IncomingWebhook;

    /**
     * The id of the incoming webhook to edit
     */
    hookId: string;

    /**
     * Whether or not incoming webhooks are enabled.
     */
    enableIncomingWebhooks: boolean;

    /**
     * Whether to allow configuration of the default post username.
     */
    enablePostUsernameOverride: boolean;

    /**
     * Whether to allow configuration of the default post icon.
     */
    enablePostIconOverride: boolean;

    /**
     * Whether the user can bypass the channel lock requirement.
     */
    canBypassChannelLock?: boolean;

    actions: {

        /**
         * The function to call to update an incoming webhook
         */
        updateIncomingHook: (hook: IncomingWebhook) => Promise<ActionResult>;

        /**
         * The function to call to get an incoming webhook
         */
        getIncomingHook: (hookId: string) => Promise<ActionResult>;
    };
};

const EditIncomingWebhook: React.FC<Props> = ({
    team,
    hook,
    hookId,
    enableIncomingWebhooks,
    enablePostUsernameOverride,
    enablePostIconOverride,
    canBypassChannelLock,
    actions,
}: Props) => {
    const [serverError, setServerError] = useState('');

    useEffect(() => {
        if (enableIncomingWebhooks) {
            actions.getIncomingHook(hookId);
        }
    }, [actions, enableIncomingWebhooks, hookId]);

    const editIncomingHook = async (newHook: IncomingWebhook) => {
        setServerError('');

        if (hook?.id) {
            newHook.id = hook.id;
        }

        const result = await actions.updateIncomingHook(newHook);

        if ('data' in result) {
            getHistory().push(`/${team.name}/integrations/incoming_webhooks`);
            return;
        }

        if ('error' in result) {
            const {error} = result;
            setServerError(error.message);
        }
    };

    if (!hook) {
        return <LoadingScreen/>;
    }

    return (
        <AbstractIncomingWebhook
                team={team}
                header={messages.header}
                footer={messages.footer}
                loading={messages.loading}
                enablePostUsernameOverride={enablePostUsernameOverride}
                enablePostIconOverride={enablePostIconOverride}
                canBypassChannelLock={canBypassChannelLock}
                action={editIncomingHook}
                serverError={serverError}
                initialHook={hook}
            />
    );
};

export default EditIncomingWebhook;