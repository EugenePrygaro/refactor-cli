import React, {useEffect, useState, type JSX} from 'react';
import {Modal} from 'react-bootstrap';
import {FormattedDate, FormattedMessage, FormattedTime} from 'react-intl';
import type {UserAccessToken, UserProfile} from '@mattermost/types/users';
import {Client4} from 'mattermost-redux/client';
import * as UserUtils from 'mattermost-redux/utils/user_utils';
import RevokeTokenButton from 'components/admin_console/revoke_token_button';
import ExternalLink from 'components/external_link';
import LoadingScreen from 'components/loading_screen';
import Avatar from 'components/widgets/users/avatar';
import {DeveloperLinks} from 'utils/constants';

export type Props = {

    /**
     * The user the roles are being managed for
     */
    user: UserProfile;

    /**
     * The personal access tokens for a user, object with token ids as keys
     */
    userAccessTokens?: Record<string, UserAccessToken>;

    onExited: () => void;
    actions: {

        /**
         * Function to get a user's access tokens
         */
        getUserAccessTokensForUser: (userId: string, page: number, perPage: number) => void;
    };
};

export default function ManageTokensModal({
    user,
    userAccessTokens,
    onExited,
    actions,
}: Props): JSX.Element {
    const [show, setShow] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const userId = user ? user.id : null;
        if (userId) {
            actions.getUserAccessTokensForUser(userId, 0, 200);
        }
    }, [actions, user]);

    const handleError = (error: string): void => {
        setError(error);
    };

    const onModalDismissed = (): void => {
        setShow(false);
    };

    const renderContents = (): JSX.Element => {
        let name = UserUtils.getFullName(user);
        if (name) {
            name += ` (@${user.username})`;
        } else {
            name = `@${user.username}`;
        }

        let tokenList;
        if (userAccessTokens) {
            const userAccessTokensList = Object.values(userAccessTokens);

            if (userAccessTokensList.length === 0) {
                tokenList = (
                    <div className='manage-row__empty'>
                        <FormattedMessage
                            id='admin.manage_tokens.userAccessTokensNone'
                            defaultMessage='No personal access tokens.'
                        />
                    </div>
                );
            } else {
                tokenList = userAccessTokensList.map((token: UserAccessToken) => {
                    const hasExpiry = Boolean(token.expires_at && token.expires_at > 0);
                    const expired = hasExpiry && (token.expires_at as number) < Date.now();
                    let status: 'active' | 'expired' | 'inactive' = 'active';
                    if (!token.is_active) {
                        status = 'inactive';
                    } else if (expired) {
                        status = 'expired';
                    }
                    return (
                        <div
                            key={token.id}
                            className='manage-teams__team'
                        >
                            <div className='manage-teams__team-name'>
                                <div className='whitespace--nowrap overflow--ellipsis'>
                                    <FormattedMessage
                                        id='admin.manage_tokens.userAccessTokensNameLabel'
                                        defaultMessage='Token Description: '
                                    />
                                    {token.description}
                                    {' '}
                                    <span className={`setting-box__token-status setting-box__token-status--${status}`}>
                                        {status === 'active' && (
                                            <FormattedMessage
                                                id='admin.manage_tokens.status.active'
                                                defaultMessage='Active'
                                            />
                                        )}
                                        {status === 'expired' && (
                                            <FormattedMessage
                                                id='admin.manage_tokens.status.expired'
                                                defaultMessage='Expired'
                                            />
                                        )}
                                        {status === 'inactive' && (
                                            <FormattedMessage
                                                id='admin.manage_tokens.status.inactive'
                                                defaultMessage='Disabled'
                                            />
                                        )}
                                    </span>
                                </div>
                                <div className='whitespace--nowrap overflow--ellipsis'>
                                    <FormattedMessage
                                        id='admin.manage_tokens.userAccessTokensIdLabel'
                                        defaultMessage='Token ID: '
                                    />
                                    {token.id}
                                </div>
                                <div className='whitespace--nowrap overflow--ellipsis'>
                                    <FormattedMessage
                                        id='admin.manage_tokens.expiry'
                                        defaultMessage='Expires: '
                                    />
                                    {hasExpiry ? (
                                        <>
                                            <FormattedDate
                                                value={token.expires_at}
                                                year='numeric'
                                                month='short'
                                                day='2-digit'
                                            />
                                            {' '}
                                            <FormattedTime value={token.expires_at}/>
                                        </>
                                    ) : (
                                        <FormattedMessage
                                            id='admin.manage_tokens.expiry.never'
                                            defaultMessage='Never'
                                        />
                                    )}
                                </div>
                            </div>
                            <div className='manage-teams__team-actions'>
                                <RevokeTokenButton
                                    tokenId={token.id}
                                    onError={handleError}
                                />
                            </div>
                        </div>
                    );
                });
            }
        } else {
            tokenList = <LoadingScreen/>;
        }

        return (
            <div>
                <div className='manage-teams__user'>
                    <Avatar
                        username={user.username}
                        url={Client4.getProfilePictureUrl(user.id, user.last_picture_update)}
                        size='lg'
                    />
                    <div className='manage-teams__info'>
                        <div className='manage-teams__name'>
                            {name}
                        </div>
                        <div className='manage-teams__email'>
                            {user.email}
                        </div>
                    </div>
                </div>
                <div className='pt-3'>
                    <FormattedMessage
                        id='admin.manage_tokens.userAccessTokensDescription'
                        defaultMessage='Personal access tokens function similarly to session tokens and can be used by integrations to <linkAuthentication>interact with this Mattermost server</linkAuthentication>. Tokens are disabled if the user is deactivated. Learn more about <linkPersonalAccessTokens>personal access tokens</linkPersonalAccessTokens>.'
                        values={{
                            linkAuthentication: (msg: React.ReactNode) => (
                                <ExternalLink
                                    href='https://api.mattermost.com/#tag/authentication'
                                    location='manage_tokens_modal'
                                >
                                    {msg}
                                </ExternalLink>
                            ),
                            linkPersonalAccessTokens: (msg: React.ReactNode) => (
                                <ExternalLink
                                    href={DeveloperLinks.PERSONAL_ACCESS_TOKENS}
                                    location='manage_tokens_modal'
                                >
                                    {msg}
                                </ExternalLink>
                            ),
                        }}
                    />
                </div>
                <div className='manage-teams__teams'>
                    {tokenList}
                </div>
            </div>
        );
    };

    return (
        <Modal
                show={show}
                onHide={onModalDismissed}
                onExited={onExited}
                dialogClassName='a11y__modal manage-teams'
                role='none'
                aria-labelledby='manageTokensModalLabel'
            >
                <Modal.Header closeButton={true}>
                    <Modal.Title
                        componentClass='h1'
                        id='manageTokensModalLabel'
                    >
                        <FormattedMessage
                            id='admin.manage_tokens.manageTokensTitle'
                            defaultMessage='Manage Personal Access Tokens'
                        />
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    {renderContents()}
                    {error}
                </Modal.Body>
            </Modal>
    );
}