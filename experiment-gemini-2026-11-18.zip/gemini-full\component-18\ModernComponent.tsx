import React, {type JSX, useEffect} from 'react';
import type {MessageDescriptor} from 'react-intl';
import {FormattedMessage} from 'react-intl';
import type {ButtonAsChildProps, ButtonProps} from '@mattermost/compass-ui/components/button';
import {FeatureDiscoveryPanel} from '@mattermost/compass-ui/components/feature-discovery-panel';
import type {AnalyticsState} from '@mattermost/types/admin';
import type {CloudCustomer} from '@mattermost/types/cloud';
import type {ClientLicense} from '@mattermost/types/config';
import {EmbargoedEntityTrialError} from 'components/admin_console/license_settings/trial_banner/trial_banner';
import AlertBanner from 'components/alert_banner';
import ExternalLink from 'components/external_link';
import LoadingSpinner from 'components/widgets/loading/loading_spinner';
import {licenseSkuToLabel} from 'components/widgets/tag/sku_tag';
import type {LicenseSkus} from 'utils/constants';
import {AboutLinks, LicenseLinks} from 'utils/constants';
import {goToMattermostContactSalesForm} from 'utils/contact_support_sales';
import type {ModalData} from 'types/actions';
import './feature_discovery.scss';

type PanelButtonProps = ButtonProps & {
    'data-testid'?: string;
};

type Props = {
    featureName: string;
    minimumSKURequiredForFeature: LicenseSkus;

    title: MessageDescriptor;
    copy: MessageDescriptor;

    learnMoreURL: string;

    featureDiscoveryImage: JSX.Element;

    prevTrialLicense: ClientLicense;

    stats?: AnalyticsState;
    actions: {
        getPrevTrialLicense: () => void;
        getCloudSubscription: () => void;
        openModal: <P>(modalData: ModalData<P>) => void;
    };
    isEnterpriseReady: boolean;
    isCloud: boolean;
    isCloudTrial: boolean;
    hadPrevCloudTrial: boolean;
    isSubscriptionLoaded: boolean;
    isPaidSubscription: boolean;
    customer?: CloudCustomer;
    showSkuTag?: boolean;
    openTrialForm?: (onClose?: () => void) => void;
};

const FeatureDiscovery: React.FC<Props> = (props) => {
    const {
        title,
        copy,
        featureDiscoveryImage,
        isCloud,
        isCloudTrial,
        isSubscriptionLoaded,
        showSkuTag,
        minimumSKURequiredForFeature,
        actions,
        customer,
        isEnterpriseReady,
        learnMoreURL,
        openTrialForm,
        prevTrialLicense,
    } = props;

    useEffect(() => {
        actions.getPrevTrialLicense();
    }, [actions]);

    const contactSalesFunc = () => {
        const customerEmail = customer?.email || '';
        const firstName = customer?.contact_first_name || '';
        const lastName = customer?.contact_last_name || '';
        const companyName = customer?.name || '';
        const utmMedium = isCloud ? 'in-product-cloud' : 'in-product';
        goToMattermostContactSalesForm(firstName, lastName, companyName, customerEmail, 'mattermost', utmMedium);
    };

    const renderLearnMoreSecondaryAction = (
        emphasis: ButtonProps['emphasis'] = 'secondary',
        size: ButtonProps['size'] = 'medium',
    ): ButtonAsChildProps => ({
        asChild: true,
        emphasis,
        size,
        children: (
            <ExternalLink
                location='feature_discovery'
                href={learnMoreURL}
                data-testid='featureDiscovery_secondaryCallToAction'
            >
                <FormattedMessage
                    id='admin.ldap_feature_discovery.call_to_action.secondary'
                    defaultMessage='Learn more'
                />
            </ExternalLink>
        ),
    });

    const renderContactSalesPrimaryAction = (size: ButtonProps['size'] = 'medium'): PanelButtonProps => ({
        emphasis: 'primary',
        size,
        'data-testid': 'featureDiscovery_primaryCallToAction',
        onClick: () => {
            contactSalesFunc();
        },
        children: (
            <FormattedMessage
                id='admin.ldap_feature_discovery_cloud.call_to_action.primary_sales'
                defaultMessage='Contact sales'
            />
        ),
    });

    const renderStartTrialPrimaryAction = (size: ButtonProps['size'] = 'medium'): PanelButtonProps => ({
        emphasis: 'primary',
        size,
        id: 'start_trial_btn',
        'data-testid': 'featureDiscovery_primaryCallToAction',
        onClick: () => {
            openTrialForm?.();
        },
        children: (
            <FormattedMessage
                id='admin.ldap_feature_discovery.call_to_action.primary'
                defaultMessage='Start trial'
            />
        ),
    });

    const renderPostTrialActions = () => {
        return {
            primaryAction: renderContactSalesPrimaryAction(),
            secondaryAction: renderLearnMoreSecondaryAction('tertiary'),
        };
    };

    const renderCloudStartTrialActions = () => ({
        primaryAction: renderContactSalesPrimaryAction(),
        secondaryAction: renderLearnMoreSecondaryAction(),
    });

    const renderHostStartTrialActions = () => ({
        primaryAction: renderStartTrialPrimaryAction(),
        secondaryAction: renderLearnMoreSecondaryAction('tertiary'),
    });

    const renderTrialExtras = (gettingTrialError?: React.ReactNode) => {
        return (
            <>
                {gettingTrialError}
                {(!isCloud) && (
                    <p className='trial-legal-terms'>
                        <FormattedMessage
                            id='admin.feature_discovery.trial-request.accept-terms'
                            defaultMessage='By clicking <highlight>Start trial</highlight>, I agree to the <linkEvaluation>Mattermost Software Evaluation Agreement</linkEvaluation>, <linkPrivacy>Privacy Policy</linkPrivacy> and receiving product emails.'
                            values={{
                                highlight: (msg: React.ReactNode) => (
                                    <strong key='trial-terms-highlight'>{msg}</strong>
                                ),
                                linkEvaluation: (msg: React.ReactNode) => (
                                    <ExternalLink
                                        key='trial-terms-evaluation'
                                        location='feature_discovery'
                                        href={LicenseLinks.SOFTWARE_SERVICES_LICENSE_AGREEMENT}
                                    >
                                        {msg}
                                    </ExternalLink>
                                ),
                                linkPrivacy: (msg: React.ReactNode) => (
                                    <ExternalLink
                                        key='trial-terms-privacy'
                                        location='feature_discovery'
                                        href={AboutLinks.PRIVACY_POLICY}
                                    >
                                        {msg}
                                    </ExternalLink>
                                ),
                            }}
                        />
                    </p>
                )}
            </>
        );
    };

    if (isCloud && !isSubscriptionLoaded) {
        return (<LoadingSpinner/>);
    }

    let gettingTrialError: React.ReactNode = '';

    if (isCloud && isCloudTrial && isSubscriptionLoaded) {
        return (
            <div className='FeatureDiscovery'>
                    <AlertBanner
                        mode='info'
                        title={
                            <FormattedMessage
                                id='admin.featureDiscovery.WarningTitle'
                                defaultMessage='Your trial has started and updates are being made to your license.'
                            />
                        }
                        message={
                            <>
                                <FormattedMessage
                                    id='admin.featureDiscovery.WarningDescription'
                                    defaultMessage='Your License is being updated to give you full access to all the Enterprise Features. This page will automatically refresh once the license update is complete. Please wait '
                                />
                                <LoadingSpinner/>
                            </>
                        }
                    />
                </div>
        );
    }

    const showPostTrialCta = prevTrialLicense?.IsLicensed === 'true' || isEnterpriseReady === false;
    const showHostStartTrialActions = !showPostTrialCta && !isCloud;

    let panelActions: {
        primaryAction?: PanelButtonProps;
        secondaryAction?: ButtonAsChildProps;
    };
    if (showPostTrialCta) {
        panelActions = renderPostTrialActions();
    } else if (isCloud) {
        panelActions = renderCloudStartTrialActions();
    } else {
        panelActions = renderHostStartTrialActions();
    }

    // Pass null when hidden so the panel does not fall back to its PROFESSIONAL default.
    const skuLabel = showSkuTag ? licenseSkuToLabel(minimumSKURequiredForFeature) : null;

    return (
        <div
                className='FeatureDiscovery'
                data-testid='featureDiscovery'
            >
                <FeatureDiscoveryPanel
                    className='FeatureDiscovery_panel'
                    skuLabel={skuLabel}
                    title={
                        <span data-testid='featureDiscovery_title'>
                            <FormattedMessage
                                {...title}
                            />
                        </span>
                    }
                    description={
                        <FormattedMessage
                            {...copy}
                        />
                    }
                    primaryAction={panelActions.primaryAction}

                    // FeatureDiscoveryPanel types secondaryAction as ButtonProps; asChild is supported at runtime in compass-ui ≥0.1.0-alpha.15
                    secondaryAction={panelActions.secondaryAction as ButtonProps | undefined}
                    illustration={{
                        'aria-label': '',
                        children: featureDiscoveryImage,
                    }}
                />
                {showHostStartTrialActions && renderTrialExtras(gettingTrialError)}
            </div>
    );
};

export default FeatureDiscovery;